# Vault structure, adoption, and review

## Vault layout

```
<vault>/Knowledge Base/
├── index.md                      Top-level catalog; updated on every write
├── log.md                        Append-only activity log; most recent first
├── _access.yaml                  (optional) per-subtree readonly/excluded — see references/write-scope.md
├── _Schema/
│   ├── SKILL.md                  This file (canonical)
│   ├── project-keys.yaml         Registered research scope keys
│   ├── workflow-skills/          Named agent workflows built on the core contract
│   └── references/
│       ├── page-types.md         Page-type taxonomy
│       ├── frontmatter.md        Frontmatter spec for each page type
│       ├── write-scope.md        What's writeable vs. read-only
│       ├── supersession.md       Supersession protocol
│       ├── operations.md         Detailed per-operation specs
│       └── audit-checks.md       Per-check detail for the audit operation
├── Sources/
│   ├── Articles/                 Captured web/PDF content
│   ├── Sessions/                 Conversation transcripts OR session captures
│   ├── Books/                    Book notes/excerpts
│   ├── Papers/                   Academic papers
│   └── Videos/                   Video transcripts/notes
├── Notes/
│   ├── Research/<scope>/         Project- or domain-scoped research (incl. hubs + snapshots)
│   ├── Insights/                 Distilled cross-cutting lessons
│   ├── Failures/                 Documented failure modes
│   ├── Patterns/                 Reusable patterns
│   ├── Experiments/<domain>/     Primary experiments — protocol/data/results
│   └── Productions/<medium>/     Creative artifacts + production knowledge
├── Entities/
│   ├── People/
│   ├── Concepts/
│   ├── Libraries/
│   └── Decisions/
└── Evidence/
    └── <scope>/                  Per-incident binary/document/factual preservation
```

**This tree is the `Knowledge Base/` layer only — not the shape of your whole vault.**
The vault around it is yours: any top-level folders you keep (`Daily/`, `Projects/`,
`Reference/`, a journal — whatever) sit *beside* `Knowledge Base/` and are **read-only
input** to this skill. Don't infer a fixed vault shape from the tree above. On your
first engagement in a vault, run `inspect_memory` once to learn its real top-level layout
(see § Assessing or adopting a vault you didn't build), then treat everything outside
`Knowledge Base/` as read-only. Only `Knowledge Base/` is governed and writeable.

`<vault>` resolves to your markdown vault root (Obsidian optional) — the folder that
contains `Knowledge Base/`, set via `EXOMEM_VAULT_PATH`. Verify allowed filesystem
paths before writing.

The research scopes are an open set you grow over time, registered in
`_Schema/project-keys.yaml` (see § Research scope keys). New users start with a
small set (e.g. `personal`, `project-alpha`, `work`) and add their own.

### Assessing or adopting a vault you didn't build

**Make this your first move in any unfamiliar vault.** For import/adoption questions, run **inspect_memory(operation="imports.scan")** first: it wraps the bounded scan, states the read-only contract, suggests likely knowledge packs, reports a bounded semantic census, and lists safe next actions. It never rewrites originals in scan-only mode; explicit write modes stay under `Knowledge Base/` and either save the manifest or copy selected legacy text files as Sources with original path/hash provenance. `compile-selected` returns a proposal, not a compiled note: review it, then call `note()` so the normal semantic precommit contract still applies.

For structural questions —
"what does this vault look like," "how is this vault organized," "is there junk in
here" — and simply to learn the layout before you write, run **inspect_memory** first: one bounded,
read-only report of folder structure, counts, frontmatter coverage, naming
patterns, and junk candidates (zero-byte files, sync-conflict duplicates). It
works on any folder under the vault root, including trees outside
`Knowledge Base/` (a `Daily/` or `Journal/` folder), and on vaults with no KB at
all. The folders it reports *outside* `Knowledge Base/` are read-only input — link
to them, never write them; only `Knowledge Base/` is governed. Drill down from there: `inspect_memory` on folders of interest,
`search_memory scope="vault"` for content, targeted `read_page` for individual files. Use adoption output to decide whether to save a manifest, copy selected originals into Sources, or compile selected material into governed notes; do not rewrite the old vault by default. **Never
bulk-read a vault file-by-file to answer a structural question** — the report
answers in one call what would otherwise cost hundreds of reads.

## Activity log

`log.md` at the vault root is the append-only chronological record of every
confirmed write. **Most recent first.** Format per entry:

```
## [YYYY-MM-DD] <op> | <title>

<one-paragraph description summarising what was written and why>
```

Distinction from `index.md`:

- **`log.md`** is the *activity feed* — chronological, durable, content-focused.
- **`index.md` § Recent activity** is a *cap-50 view* derived from log.md — terse
  one-line summaries for quick navigation. When log.md grows beyond cap, older
  entries fall off the index but remain in log.md.

Both update on every confirmed write.

## Audit (lint) checks

The audit operation, `inspect_memory(operation="maintenance.audit")`, runs read-only checks and proposes fixes (never
auto-fixes); every audit presentation remains read-only. The default
`detail="actionable"` puts current blockers first, then malformed semantic units
and unregistered relation work, then ordinary findings. Grandfathered relation-
disposition debt is grouped into one deterministic `legacy_backlog` with exact
counts and bounded samples instead of flooding the action list. Use
`detail="full"` to enumerate the raw findings; `legacy_sample_limit` is an
integer from 0 through 50 and controls samples in actionable output only. The
checks cover:
orphans, broken wikilinks, supersession integrity, stale frontmatter,
`index.md`/`log.md` drift, aged unprocessed sources (oldest-first — pair with
`inspect_memory`), status/location mismatch, unfinished experiments, stalled
production lifecycles, **stale-review candidates** (active conclusions that are old
AND rarely surfaced in `find` AND low inbound-link degree — surfaced for review
only, never decayed or down-ranked; hubs/snapshots excluded as expected-to-drift),
unregistered project keys, and embedding drift.

Two categories report exact duplicates and run only when you ask for them:
`duplicate_content` (identical bytes in two or more live Sources or Evidence
pages) and `duplicate_source_url` (one URL captured with different text). Pass
them in `categories`, for example
`list_review_items(categories=['duplicate_content'])`. The default review
skips them, so an old vault's first run cannot bury the daily queue. Each `duplicate_content` finding carries the exact `fold-duplicate` step
for every copy, or says why it offers none. Propose those steps as one curation plan, then preview, confirm
and apply it ([curation](#curation)); an undo is a compensation plan.

Per-check detail — exactly what each flags, its severity, and the proposed fix —
is in **`audit-checks.md`**.

## What this skill does NOT do

- Touch anything outside `Knowledge Base/`.
- Auto-compile *blindly* after every capture. Compilation is a deliberate step
  taken at a stepping-stone; it's always reported, never a silent dump of raw
  transcripts or every passing remark. "No silent dump" targets *noise* —
  transcripts, mid-flight tangents — not *signal*: it never licenses pruning
  context or detail from a note (see *Comprehensive coverage, minimal expression*
  under Proactive engagement).
- Score a claim. A claim carries no confidence score, and its verdict is a
  judgment in words, never a number. A degree of belief that its holder stated
  is a `## Belief` unit: see "Recording a degree of belief" in `page-types.md`.
  Use citation count and recency as the trust signal for the claim itself.
- Apply retention decay or "forgetting curves." Old material stays. If superseded,
  mark it; if irrelevant, archive into an `_archive/` subfolder. (`list_review_items` and `decide_review_item`'s
  `stale_review` check **surfaces** old/cold/low-inbound conclusions as *review
  candidates* for you to judge — but never auto-decays, down-ranks, hides, or moves
  anything; review surfacing has no effect on `search_memory`/`find` ordering.
  Surfacing a candidate ≠ a forgetting curve. Authored typed relations DO
  legitimately inform retrieval ranking — that is connectivity you wrote, not
  decay the system invented.)
- Run on a schedule, or read or write your vault in the background. Every operation
  happens inside a turn — because you asked, or because the conversation reached a
  point where consulting or capturing is clearly warranted. (On clients that support
  them, optional hooks may *remind* the assistant to check at the start or end of a
  turn. A reminder is not an operation: it prompts the same in-turn judgment
  described under **Proactive engagement**, and nothing touches the vault until the
  assistant decides to act.)
- Modify `Sources/` or `Evidence/` files after creation. Mistakes get superseded,
  not edited.

## Maintenance modes (`inspect_memory` and `manage_memory`)

Remote `manage_memory` publishes structured-file, tag-variant, curation and
maintenance-job writes. `inspect_memory` publishes the admitted read-only
maintenance variants, including curation work items, previews, status and
maintenance jobs. A remote client runs the whole curation workflow: work item,
proposal, preview, one exact-plan approval, apply, resume and compensation. Follow the
active schema; a descriptive mode name never grants remote admission.


Audit is read-only. `fix` and `backfill-ids` rewrite content (wikilinks, frontmatter, stable IDs) and dry-run by default. `reconcile` heals index-count and sidecar drift from out-of-band edits, is idempotent and non-destructive, and writes by default (`dry_run=true` previews). The local CLI runs these writes in one call.

### Remote maintenance jobs

A remote `fix`, `backfill-ids`, `capture-metadata`, `reconcile` or `convert-originals` runs as a background job, preview and write alike, not as one call. Only the vault owner can start, read or cancel one, and one job runs per vault.

1. Preview with `inspect_memory`, `dry_run=true`. The owner gets a `run_id` and `preview: true` at once: a preview of a large vault outlasts one request, so it runs as a read-only job. When it is `completed`, its receipt's `result` carries the `plan_id`. A caller other than the owner, and the local CLI, get the report in one call.
2. Start with `manage_memory`: the same mode and flags, `dry_run=false`, that `plan_id` and a one-line `why`. It returns a `run_id` at once. Without both it returns `MAINTENANCE_PLAN_REQUIRED` and starts nothing.
3. Follow with `inspect_memory(operation="maintenance.job")` plus the `run_id`, until the state is `completed`, `failed`, `cancelled` or `interrupted`. Without a `run_id` it lists recent jobs.
4. Stop one early with `manage_memory(operation="maintenance.cancel_job")` (`run_id`, `why`). The job stops at its next checkpoint.
5. Read the receipt. A finished job's status holds the totals: pages `committed`, `skipped_changed` (the page changed after the preview) and `outcome_unknown`. The page list is long, so read it page by page: pass the receipt's `next_cursor` as `cursor` to the same call, and repeat with each returned `next_cursor` until it is `null`. Each entry names a path, its kind and, for `backfill-ids`, the minted ID. A preview's entries are kind `planned`: the items its `plan_id` covers (paths, components or identities). A `fix` entry's value says what the plan does to the page. A `backfill-ids` preview also lists kind `identity_issue` and `skipped` entries, each with its detail as the value.

If the vault changed after the preview, the job returns `STALE_MAINTENANCE_PLAN`, writes nothing and gives a fresh `plan_id`: preview again. Another start while a job runs returns `MAINTENANCE_JOB_ACTIVE`, and its `retry` reads the running job by its `run_id`. `fix` and `backfill-ids` write in short chunks that let other writes through. `reconcile` holds writes only in short holds, one per phase that writes, and other writes go through between them. A `MUTATION_BUSY` refusal during one of its holds names the job's `run_id`. Applying `collections-store-export` is host work: run it with the service stopped.

### convert-originals

An archive created before shared original storage keeps each original as an ordinary file at its own path. `convert-originals` stores the bytes of each original once in the shared store and then removes the ordinary file. The original keeps its path, and its page keeps every byte, with its references and grants. Only the owner can run it, and it dry-runs by default.

The preview counts `would_convert`, `already_shared` and `store_bound`, which counts originals whose only copy is a stored version. It lists each `unreadable` original with a reason, and conversion leaves it unchanged. The write adds `converted`, `skipped_changed` (the original or its page changed after the inventory) and `kept_pinned` (a reader or a media job held the file).

A run that stops leaves every original readable. Run the conversion again to finish an interrupted run or the skipped originals. `ORIGINAL_POOL_LIFECYCLE_REQUIRED` means that the service's launcher cannot serve shared storage yet: the operator must update the launcher first.

### capture-metadata

A photo or video filed before capture metadata was recorded has a page without the capture fields (`capture_time`, `capture_date`, `capture_date_source`, `capture_lat`, `capture_lon`, `camera_make`, `camera_model`, `pixel_width`, `pixel_height`). `capture-metadata` reads each original that has bytes on the volume and adds the fields its file states. A file that states no time takes the time its file name states, when a registered name format reads one. It replaces only that block of the page: the extracted text, the preserved notes and every other field stay as written. Only the owner can run it, and it dry-runs by default.

The preview counts `would_update`, `already_current`, `no_capture_metadata` (the file states nothing) and `skipped`, with each reason's count, and it lists up to 200 skipped pages. A page is skipped when its original has `bytes not on the volume` (the job never fetches one back), when it holds unmarked preserved notes (`AMBIGUOUS_SIDECAR_BOUNDARY`), or when this host has no decoder for the original's kind. The write adds `updated` and `skipped_changed` (the page changed after the preview). Run it again after the bytes of a skipped original return.

`capture_date_source` names where a date came from, as a key of the `capture-date-sources` vocabulary: `camera-exif` (the file states it), `matched-original`, `file-name`, or `source-date`. The first three are evidence. `source-date` is a fallback: a photo or video with no evidence date answers a `page.capture_date` filter with the day it was filed, labelled `source-date`, and nothing is stored. Filter on `page.capture_date_source` to keep or drop those. A date of a higher source is never replaced by a lower one, in this order: camera, matched original, file name. The vault overlay `_Schema/capture-date-name-formats.yaml` adds file-name formats: each needs a `pattern` that names the groups `year`, `month`, `day`, `hour`, `minute` and `second`, a `maker`, and a one-line `description` of why the name states a capture time.

`recover=true` also matches each photo that states no date to an original that states one, among the camera-dated images in the vault and the images in `originals_root`, a read-only folder of originals on a personal server (an absolute path outside the vault, refused on Evermatter Cloud; it implies `recover`). A match is accepted only when exactly one capture time explains the photo, by picture structure and shape. The page then records `capture_date_matched_from`: a page id, or a path inside `originals_root`. The job never writes, moves or copies anything in that folder. The preview adds `dated_by_source` (the source of each date the photos will carry after the write), `undated` (photos left without an evidence date), and `unmatched` with each reason's count and up to 200 listed pages. Run it again after new originals arrive in the vault or the folder.

### structured-files

Previews one Planning or Records collection's manifest-declared human filenames and managed readable bodies, including governed inbound-link rewrites. Preview is read-only; apply needs the exact `plan_id` and `source_snapshot` and `why`, and commits atomically. Durable identity and mutable state stay in frontmatter, not filenames.

### curation

The governed multi-step mode. The agent authors a closed typed plan from explicit context, or `relocate` derives one. Evermatter validates and fingerprints it and records one exact-plan approval (`expected_plan_fingerprint`). Each apply or resume then runs the plan's steps, one write hold per step, until the run ends or the request's time is spent. Other writes land between steps. A request that stops early answers `executing` with `progress` (steps, committed, this call), and `resume` continues the same approval. A refusal after committed steps answers `stopped` beside the progress instead of an error. Follow `next_action`: `resume` after a busy vault or run, otherwise the run's `partial` or `blocked` answer. `work-item`, `preview` and `status` are read-only. Proposal, execution and separately reviewed compensation use the shared mutation terminal.

`relocate` moves a set of pages into one project, renames them to their titles, or both, in one reviewed plan. Pass `pages` (refs or vault paths) or one `review_ref`, and `to_project` to change project. `from_project` names the key to replace when a page carries several; `folder` names where the notes of a new key live. Evermatter derives every step:

- a move, or an in-place field edit, of each page;
- an edit of the project fields of each Source that a moved page cites;
- closing `repoint-links` steps that rewrite links to the old paths, a few referring pages per step.

A cited Source gains the new key. It loses the old key only when no page outside the set still cites it under that key. A page without a typed folder, such as an entity, stays in its own folder: it takes its title-named path there and changes its fields. The reply is a grouped summary with counts and samples, never the whole plan: show it as the preview, then approve its fingerprint with `apply`. A proposal that runs short of the request's time answers `preparing` with `progress` (steps, prepared, this call). Make the same `relocate` call again, as `next_action` says, until it seals; each call keeps the steps the earlier ones prepared. A `review_ref` batch is sized to what one plan holds, and the pages left for later are counted under `deferred_to_next_batch`. A page the lane cannot change is listed under `refused` with its code, and the other pages still seal. `propose-compensation` undoes the whole run as one plan; a project key that the run registered stays registered.

Page steps cannot target raw Sources or Evidence, Planning, Records, workflow contracts, schema/admin state, or trash internals. `move`, `delete` and `supersede` keep refusing Sources and Evidence. Two fold steps are the only way the lane retires one of their pages, and each moves bytes to the trash only after it re-checks that identical bytes are held elsewhere:

- `fold-duplicate` folds one copy into a canonical page that holds identical bytes in the same lane. The canonical page gains the copy's families, import mappings and back-references. The copy is marked superseded, and every page that cited it now cites the canonical page. It refuses a copy across lanes, a raw-protected page and bytes that differ. Read the exact step schema in the curation work item.
- `fold-recap-revisions` moves the superseded recap files of one episode into the history of its live page. Use it for an episode that still has many of them from the earlier layout.

A compensation plan restores the pages and bytes of either fold. Typed `append-record` and `update-record` steps support Records collections that use `markdown-items` or `sqlite`. Store collections require their serving service; if it is unavailable, a prepared run remains resumable. Planning steps remain unsupported.

`hydration_recheck` is a same-identity continuation ordinal (1 to 8). The eighth is closure-only and cannot bind another plan.

### tag-variants

Lists tags that differ only by case, separator or plural, grouped with visible page counts and the most-used written form as canonical (a tie is listed, never rewritten). Preview is read-only; `apply=true` with the preview's `plan_id` and a one-line `why` rewrites one bounded batch of minority variants to the canonical tag and logs a rollback record. Only the `tags` key changes; Sources, Evidence, Records, Planning and other owned trees are untouched. Preview again for the next batch. `exclude_groups` keeps named groups out of preview and apply alike.

### collections-store

Reports whether each file Records and Planning collection would move into the collection store cleanly. Call it with `kind` alone: it is owner-only and writes nothing. Each collection reports its rows, legacy audit status, round-trip proof, stamped items and any blocker. A stamped item carries the vault's note identity (`exomem_id`), which the move sets aside. A blocker names its code and, for a failed proof, the check letter. Datasets are skipped, and every copy of a duplicated collection identity is blocked.

`inventory` lists every collection, in the store and in files, one page at a time. Each row names its authority (`store` or `file`), storage strategy, view mode, rows, item views, audit status, held candidates, stamped items and any blocker. A value that is unknown or does not apply is null. When `next_cursor` is set, call again with it as `cursor` for the next page.

The report separates vault setup in `coordinator` and, when needed, a vault-level `blocker`. Without configured writer-lease coordination, a vault with collections to migrate stays `blocked` even when every collection passes. The vault verdict is `migratable`, `blocked` or `nothing_to_migrate`. Moving a vault is a separate offline upgrade step.

### collections-store-export

Previews the return of a migrated vault's store collections to file-canonical files. It is owner-only and writes nothing. For each collection it reports whether the store wrote it, and any blocker: a collection the store created, one over a file-mode bound, a value with no file form, or a view changed by hand. The vault verdict is `exportable`, `blocked`, `export_pending` or `nothing_to_export`. Applying the preview's `plan_id` with a `why` is the owner's offline step, `exomem collections export --plan-id ID --why REASON`, with the service stopped; the service refuses the apply.

### collections-cutover

Previews the move of every structured collection to SQLite-only storage. It is owner-only and writes nothing. For each collection it names the steps the apply takes: `migrate` for a collection still in files, `convert` for one with item files, `rewrite_strategy` for a summary collection, or none. It lists every blocker with its fix, and returns a `plan_id`. Applying that `plan_id` with a `why` is the owner's offline step, `exomem collections cutover --plan-id ID --why REASON --backup-to FILE`, with the service stopped. The apply takes and verifies a backup first, checks each collection's rows after its step, and resumes after a crash when run again with a new `--backup-to` file. The preview counts, for each collection, the items that carry a body: after the apply, that body is read with `read_page` on the old item path or with a `query` that names the row.

### Sidecar collapse (`fix`)

`fix` also collapses media sidecars that accumulated nested copies of themselves (audit category `duplicated_sidecar`, reportable alone via `inspect_memory(operation="maintenance.audit", arguments={'categories': ['duplicated_sidecar']})`). It keeps the longest surviving `## Extracted text` (for a sidecar whose top-level block was blanked by a re-render, the one buried in a nested copy) and refuses any rewrite that would leave less transcript than it found. Frontmatter is untouched, so a still-`pending` sidecar is re-extracted normally and the recovered text is only the fallback.
