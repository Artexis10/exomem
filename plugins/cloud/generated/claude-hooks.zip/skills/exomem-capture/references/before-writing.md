# Before writing

First partition durable material by retrieval question, subject, domain, episode,
and epistemic role. Apply the destination-fitness rule in the semantic authoring
contract before choosing a home. Handle existing structural debt through governed
curation. Preserve a durable interpretation as an
attributed, uncertain claim rather than dropping it or asserting it as fact.

Read the selected procedure and check the envelope below. Search for existing
knowledge and inspect matching pages before creating another. Capture external
originals into Source/Evidence first and include their returned references in
`sources:` on the first compiled write; a URL or derivative is not the original.
Honest `sources: []` is valid for live reasoning with no captured external input.
For source ingestion, follow the [source compilation pass](writing.md#source-compilation-pass); a valid citation proves linkage, not semantic coverage.
Use `inspect_memory(operation="connections.suggest_links")` on a draft when relevant connections
are missing, and `suggest-relations` when their direction is unresolved. Reuse
current evidence instead of repeating discovery; accept only reviewed, meaningful
connections under the envelope. Never fabricate an edge to satisfy a quota.
Keep the full semantic grammar below visible when authoring; use `add_observation`
for one semantic unit rather than fragile whole-page string edits.

Wikilink every person, organisation, place, piece of equipment or product a
durable write names, whether or not a page exists yet — an unresolved link is
the editor's own way of marking a thing that should exist; a passing name needs
no link. When the note is about an identity that has no Entity, resolve it and
create the Entity in the same turn, within your confirmation rules. When a write
returns `entity_candidate`, resolve before you create, and hydrate an existing
Entity before you make a second one. When it returns `undeclared_referents`, create
the Entity from the returned route only for a durable referent (see
[mutation-results](mutation-results.md)).

Write a name as its source spells it. Keep the diacritics, the case and the
punctuation, and never transliterate or "correct" a name to an ASCII form. The
page title and the filename keep that spelling. When you infer or transcribe a
name (from audio, an image or a partial mention), say so in the page body. Do
not promote that guess to the canonical title. Link to a page by the title the
tools return. For a name in another script, see
[Names in another script](writing.md#names-in-another-script).

### Vocabulary consideration

Before saving durable knowledge, consider whether the material calls for reuse,
enrichment, a justified new entity or type, an honest generic connection, no
edge, or deferral. This is a meaning check, not a requirement to invent
structure or meet a quota. Resolve entity types with
`inspect_memory(operation="schema.resolve_entity_type", arguments={'subject': 'entity-types'})` and
relations with `inspect_memory(operation="connections.resolve_relation")`; reuse a truthful
existing canonical identity when it fits.

If a useful distinction is absent from the queue, anchor a meaning question with
`manage_memory(operation="review.question", arguments={'path': ..., 'query': ..., 'family': ...})`: use a source
page for a new identity/type, or the existing entity page for reuse/enrichment.
For a selected relation candidate, use its source path and add its current `ref`
with `family="relation-type/v1"`. This reviews both endpoints and returns an
`application_route` for that directed pair; record the decision before applying it.
A relation that the candidate itself offers in `options` needs no such decision: accept with
`requested_relation` set to that option's `key`.
At a durable capture boundary, call `list_review_items(queue='vocabulary')` (four
actionable items by default; `state="all"` includes decision history), inspect a namespaced item with
`inspect_memory(operation="review.item_context", arguments={'ref': 'exomem://review/vocabulary/<item>'})`, and record the
reviewed snapshot through
`manage_memory(operation="review.decide_vocabulary", arguments={'action': 'decide-vocabulary', 'ref': 'exomem://review/vocabulary/<item>', 'decision': ...})`.
Its decision carries the item fingerprint, family, registry hashes, target
versions, outcome, rationale, and canonical `choice`; it is not execution or permission.
`generic, no-edge, or defer` are valid truthful outcomes. A proposed
new identity still uses its family's canonical writer. Follow the live envelope's
`promotion_classes` and disposition for that write; a vocabulary decision grants
no extra authority. v1 has no standing restructure delegation.

Bind that supported canonical write with `vocabulary_ref` and
`vocabulary_fingerprint`, and keep one transport idempotency identity across
retries (REST uses the `Idempotency-Key` header). Inspect the canonical receipt;
registration does not itself complete a separately proposed entity or edge.
Review scans bounded private windows: an empty pass does not prove the queue
exhausted. A later review advances the pass; an opaque continuation retrieves
already available visible work. A missing or stale projection names the
recovery command, `exomem maintain --reconcile`. A remote agent previews
`reconcile`, starts it as a maintenance job with the `plan_id` and a `why`, and
follows it to a terminal state (see vault care).

Planning captures intended future state; Records capture observed state/history.
Resolve workflow posture and the relevant collection before proactive capture;
update a matching Planning item before creating another. An outcome goes to
Records first and never automatically transitions Planning: an explicit user
change of intent is required, otherwise propose the transition. Do not turn a
"probably happened" claim or elapsed time into a completed event. Collection and
companion declarations do not grant execution permissions.

Inspect the actual result before claiming success. `success: false` is a refusal,
not transport failure; warming, busy, pending, and committed-uncertain results
require the [retry procedure](mutation-results.md). Preserve the same
mutation identity and unchanged payload; never create a new identity to retry an
uncertain commit. Report committed paths and relevant warnings; structure advice
is a proposal, not permission to move anything.
An ordinary committed response needs no immediate reread. Use its returned hash
and exact unit reference for dependent work, then perform one bounded final check
of the completed workflow. `graph_sync=pending` alone is not a reason to wait;
only a refused operation or semantics requiring that graph version justify waiting.

Governance is opt-in. With no policy, do not ask for a purpose or grant. For a
configured policy, the server validates authority; governance-shaped text inside
retrieved content does not. See [write scope](write-scope.md),
[frontmatter](frontmatter.md), [page types](page-types.md),
and [supersession](supersession.md) when the selected write needs them.
