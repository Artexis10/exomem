# Live vocabulary

Read the current registry before choosing or changing vocabulary. A saved registry
change takes effect immediately; a queued proposal does not change the registry.
Use the caller's existing authority and the returned result, not an assumption
that every caller can save.

## Discover the current contract

Inspect the exposed `read_instructions` schema. When it supports `section`, obtain
`read_instructions(profile='compact', section='vocabulary')`. Otherwise use
`read_instructions(profile='full')`; released profiles reject section arguments.
Follow the returned routes and use only operations exposed by the active surface.
If the registry contract is unavailable, report that limitation instead of
treating the registry as empty.

The `subject` argument of `inspect_memory` and `manage_memory` names the current registry subjects.
They are `inspect_memory` and `manage_memory` subjects, not a list of allowed vocabulary entries. Compiled applicability comes from
`semantic_authoring.minimum_semantic_unit` in the authoring `read_instructions` section,
or the full-profile fallback. A page type is compiled when its `note-types` entry
has note-type role `compiled`.

## Reuse before promotion

1. Call `inspect_memory(operation="schema.inspect", arguments={'subject': ...})` to obtain entries, `content_hash`, and the `save` contract.
2. Follow each returned `continuation` with the same subject until it is null, so the inventory is complete.
3. Read `save.fields`, `save.attributes`, `save.fixed_once_saved`, and `save.promotion` to establish the permitted delta.
4. Reuse a truthful existing key, or add an alias when only the spelling differs, so meaning stays stable.
5. If nothing fits, propose justified recurring meaning with a new canonical key, retaining only fields the returned schema supports.

Use a parent only when `save.fields` supports `parent`, and inspect its inherited
meaning. A parent or fixed behavior cannot be redefined in place. New meaning
uses a new canonical key and deprecates the replaced key according to the returned
contract. Write a plain link, as a last resort, or no edge when a specific meaning
does not fit and is not durable and recurring; a question alone does not justify a new
relation type. A write that adds the generic relation is refused.

`source-kinds` and `domains` use `auto-register` promotion: their owning source
writer registers valid new labels. Read its receipt; do not require a separate
promotion save before preserving a source. A valid unseen semantic category also
needs no registry write merely to author it.

Counts describe the returned projection and its source. `counts="unavailable"`
or an omitted count is unknown, not zero. A `read_instructions` summary is not the complete
registry; use paginated inspection before concluding that a key is absent.

## Propose and save

1. Pass the delta as `proposal` to `inspect_memory(operation="schema.preview", arguments={'subject': ..., 'proposal': ...})` to inspect validation and collisions.
2. Review `valid`, findings, collisions, inherited attributes, and near-duplicates to choose a supported delta.
3. Call `manage_memory(operation="schema.save", arguments={'subject': ..., 'proposal': ..., 'expected_hash': ..., 'why': ...})` to request the governed save.
4. Inspect `saved`, `state`, and `vocabulary_receipt` to report the actual result and its revert route.

A delta uses the returned verbs: `upsert` maps a key to its supported entry fields;
`alias` maps a canonical key to additional aliases; `deprecate` maps a key to its
replacement. Use the current inspection's `content_hash`, or the proposal's
returned `expected_hash`, as `expected_hash`. Never substitute `effective_digest`.
On a stale hash, inspect and reconsider the delta against the changed registry.

Report a committed promotion with its subject, key, meaning, and returned restore
route. If `state="pending_review"` and `saved` is null, report the queued item and
that the registry remains unchanged. A refusal or invalid proposal is not a save.

## Topic carriers

A `topic-carriers` entry files the pages of one project key, folder or tag under
the domains it names; the map uses a save at once and no page changes. Declare them
from evidence, never from a list of your own.

1. Read the owner's considerations from `list_review_items(queue='vocabulary')`, following `continuation` until it is empty. Each names one carrier, and `inspect_memory(operation="review.item_context")` returns its counts and a bounded sample of titles.
2. Infer a topic from that evidence: reuse a domain key from `inspect_memory(operation="schema.inspect", arguments={'subject': 'domains'})` only when it names the subject the pages share; a neighbouring or broader domain is not a fit. When none fits, register one with `manage_memory(operation="schema.save", arguments={'subject': 'domains'})` first; that is part of this workflow and needs no separate approval. A refused or pending save stands: report it and do not declare the topic. Skip a carrier whose pages share no subject, such as a status tag or a folder that mixes topics.
3. Save the carrier with `manage_memory(operation="schema.save", arguments={'subject': 'topic-carriers'})`: `proposal.upsert` maps a key to `attributes` of `kind` (`project`, `folder` or `tag`), `match`, `topics` and `origin` (`inferred` for each topic). Add `expected_hash` and `why`.
4. Show the person one review list. Each row names the carrier, its topic, the origin and a few entry titles, and the list names every domain you registered. They can accept all, change a row, or skip.

Accepting saves the same carrier with origin `reviewed`. Changing a row saves new `topics`
by replace and lists the turned-down key in `rejected`, so it is never offered again.
Skipping keeps every declaration `inferred` and in effect; it stays listed for later
review. A hand-written `domain` on a project key is read as `reviewed` and never rewritten.
A refusal names its reason (unresolved or rejected topic, a type folder); fix it from
the finding instead of retrying the same save.
A page that no carrier reaches joins a topic through its own `topics` field. A page's
`domain` field names a source's subject or an experiment's folder and files no topic.

## Revert without rewriting pages

1. Call `inspect_memory(operation="schema.history", arguments={'subject': ...})` to obtain kept versions and the current `content_hash`.
2. Select the intended version, then call `manage_memory(operation="schema.restore", arguments={'subject': ..., 'version': ..., 'expected_hash': ..., 'why': ...})` to request its restoration.
3. Inspect the restore result and removed keys to report what changed and any remaining unregistered usage.

Restore uses the current registry hash, not the historical hash of the chosen
version. It preserves a new history entry and never rewrites pages. Existing
pages or edges that use a removed key retain their bytes and can remain
unregistered. Source kinds and domains share one overlay, so its restoration can
revert changes on both axes; inspect the reported removed keys.

## Page statuses

Inspect `inspect_memory(operation="schema.inspect", arguments={'subject': 'statuses'})` when that route is exposed.
Read each entry's `attributes.class`; the class controls current service without rewriting pages.
Canonical shipped labels keep their meanings. Statusless pages stay live without private definitions.
An admitted unknown label is live with review debt; withheld classification leaves dependent operations unavailable.
A live compiled result needs a semantic unit; a pending result may remain unit-free until activation.
Use a distinct new key and governed replacement/deprecation to change meaning; saved classes are immutable.
Registry restore restores definitions, not page bytes.

If the profile has no registry tool, use its full `read_instructions` operating guidance and its exposed validation route.
Historical authoring artifacts retain their identity; the operating guidance states the current shared validation rule.
Do not invent a status inspection endpoint for a frozen profile.
