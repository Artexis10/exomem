#!/usr/bin/env python3
"""Local structural continuation checkpoints for supported coding clients.

This module intentionally depends only on the Python standard library so the
deployed copy can run when Exomem, MCP, OAuth, and the network are unavailable.
"""

from __future__ import annotations

import argparse
import contextlib
import errno
import hashlib
import json
import os
import re
import secrets
import stat
import subprocess
import sys
import time
from collections.abc import Mapping
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
EVENT_CONTRACT_VERSION = 1
OUTPUT_CONTRACT_VERSION = 1
MAX_CHECKPOINT_BYTES = 64 * 1024
MAX_CONTEXT_BYTES = 2048
MAX_PATH_BYTES = 512
MAX_IDENTIFIER_BYTES = 512
MAX_DIRTY_PATHS = 128
MAX_ARTIFACTS = 16
MAX_OPENSPEC_ARTIFACTS = 8
MAX_INCOMPLETE_LINES = 64
MAX_ARTIFACT_READ_BYTES = 256 * 1024
MAX_ARTIFACT_CANDIDATE_READS = 64
MAX_ARTIFACT_METADATA_CANDIDATES = 512
MAX_DIRTY_ARTIFACT_CANDIDATES = MAX_ARTIFACTS
MAX_PRUNE_CANDIDATES = 16
# How long a metadata writer waits for the log lock before giving up.
#
# Sized against the operation the lock actually guards, which is not the append
# fast path: when the log is full the holder also rotates it, measured at 78 ms
# on a warm box before this module stopped re-encoding the retained records,
# and ~47 ms after. Losing the wait costs a diagnostics row and nothing else --
# every caller in `_dispatch` swallows it, because a hook must not fail a
# session over its own telemetry.
METADATA_LOG_LOCK_SECONDS = 0.5
MAX_PRUNE_LOCK_SECONDS = 0.05
MAX_PRUNE_ENUM_ENTRIES = 16
MAX_STATE_ENUM_ENTRIES = 32
MAX_PRUNE_CATALOG_ENTRIES = 512


def _over_budget(deadline: float, inspected: int) -> bool:
    """True once a slice has done some work AND run out of time.

    The `inspected` term is the whole point. A deadline consulted before the
    first unit of work turns a *bounded* pass into one that can do nothing at
    all: it inspects zero entries, so the durable cursor does not advance, so
    the next call starts in the same place and stops just as early. That is not
    a slow prune, it is no prune -- expired session state accumulates without
    bound and nothing reports it, because every call returns a perfectly
    ordinary 0.

    Bounding work has to mean at most N, never fewer than one. A slice may
    overrun its budget by a single entry; that is the price of forward
    progress, and it is bounded.
    """
    return inspected > 0 and time.monotonic() >= deadline
MAX_METADATA_LOG_BYTES = 1024 * 1024
MAX_METADATA_DURATION_MS = 60_000
TRANSCRIPT_SLICE_BYTES = 64 * 1024
RETENTION_NS = 30 * 24 * 60 * 60 * 1_000_000_000
#: Budget for one `git` probe. A checkpoint that cannot read the workspace
#: records a degradation rather than blocking the session, so this is a
#: fidelity/latency trade and not a correctness fence -- but degrading is
#: still the worse outcome, because the checkpoint's whole job is to record
#: what the workspace looked like.
#:
#: Windows gets a larger budget because the cost being bounded there is
#: mostly process creation, not the status walk: `git status --porcelain`
#: on an idle Windows box measures ~23 ms p50 for a one-file repository, of
#: which the walk is a small part, and a shared CI runner executing two
#: test shards routinely multiplies that by more than the 15x of headroom
#: 0.35 s leaves. The symptom is silent: every probe degrades, so two
#: checkpoints taken across a real workspace change record the same empty
#: structural block and hash identically.
GIT_TIMEOUT_SECONDS = 2.0 if os.name == "nt" else 0.35

_CLIENT_EVENTS = {
    "claude": {
        "PreCompact": {"trigger": {"manual", "auto"}},
        "SessionEnd": {},
        "SessionStart": {"source": {"compact", "resume"}},
    },
    "codex": {
        "PreCompact": {"trigger": {"manual", "auto"}},
        "SessionStart": {"source": {"compact", "resume"}},
    },
}
_WRITE_EVENTS = {
    "claude": {"PreCompact", "SessionEnd"},
    "codex": {"PreCompact"},
}
ADAPTER_PROVENANCE = {
    "claude": {
        "version": "2.1.207",
        "source": "https://code.claude.com/docs/en/hooks",
        "events": ("PreCompact", "SessionEnd", "SessionStart"),
    },
    "codex": {
        "version": "0.144.3",
        "source": "https://learn.chatgpt.com/docs/hooks.md",
        "source_fetched": "2026-07-13",
        "events": ("PreCompact", "SessionStart"),
    },
}
_ALIASES = {
    "event": ("hook_event_name", "hookEventName"),
    "session_id": ("session_id", "sessionId"),
    "turn_id": ("turn_id", "turnId"),
    "transcript_path": ("transcript_path", "transcriptPath"),
    "cwd": ("cwd",),
    "trigger": ("trigger",),
    "source": ("source",),
    "model": ("model",),
}
_CHECKBOX = re.compile(r"^\s*[-*]\s+\[([ xX])\]")
_HEX_64 = re.compile(r"^[0-9a-f]{64}$")
_PRUNE_CATALOG_NAME = ".prune-catalog.v1"
_PRUNE_CATALOG_TEMP = ".prune-catalog.v1.tmp"
_PRUNE_CATALOG_MAGIC = b"EXOMEM-PRUNE-V1\0"
_PRUNE_CATALOG_HEADER_BYTES = 64
_PRUNE_CATALOG_RECORD_BYTES = 579
_HEX_40 = re.compile(r"^[0-9a-f]{40}$")
_ERROR_CLASS = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")
_METADATA_EVENTS = {"PreCompact", "SessionEnd", "SessionStart"}
_METADATA_STATUSES_WITH_CHECKPOINT = {"written", "idempotent", "stale", "current", "rollback"}
_METADATA_STATUSES = _METADATA_STATUSES_WITH_CHECKPOINT | {"empty", "error"}
_ALLOWED_DEGRADATION = {
    "artifact_candidates_truncated",
    "artifact_oversized",
    "artifact_raced",
    "artifact_root_unavailable",
    "artifact_unsafe",
    "cwd_unavailable",
    "dirty_artifact_candidates_truncated",
    "git_branch_truncated",
    "git_branch_hashed",
    "git_branch_unavailable",
    "git_head_unavailable",
    "git_status_unavailable",
    "model_hashed",
    "model_truncated",
    "non_git",
    "session_id_hashed",
    "dirty_path_unsafe",
    "transcript_path_hashed",
    "transcript_unavailable",
    "turn_id_hashed",
    "workspace_name_hashed",
}
_ALLOWED_TRUNCATION = {
    "artifact_bytes",
    "artifact_candidates",
    "artifact_path_bytes",
    "artifacts",
    "branch_bytes",
    "checkpoint_artifacts",
    "checkpoint_dirty_paths",
    "dirty_artifact_candidates",
    "dirty_path_bytes",
    "dirty_path_unsafe",
    "dirty_paths",
    "incomplete_lines",
    "model_bytes",
    "openspec_artifacts",
    "session_id_bytes",
    "transcript_path_bytes",
    "turn_id_bytes",
    "workspace_name",
}
_NORMALIZATION_DEGRADATION = {
    "model_hashed",
    "model_truncated",
    "session_id_hashed",
    "turn_id_hashed",
}
_NORMALIZATION_TRUNCATION = {
    "model_bytes",
    "session_id_bytes",
    "turn_id_bytes",
}


def _utf8_prefix(value: str, limit: int) -> tuple[str, bool]:
    raw = value.encode("utf-8", "replace")
    if len(raw) <= limit:
        return value, False
    return raw[:limit].decode("utf-8", "ignore"), True


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _unsafe_text(value: str) -> bool:
    return any(
        ord(char) < 32 or ord(char) == 127 or 0xD800 <= ord(char) <= 0xDFFF for char in value
    )


def _bound_event_identifiers(event: Mapping[str, Any]) -> dict[str, Any]:
    bounded = dict(event)
    normalization = event.get("normalization")
    degradation = (
        list(normalization.get("degradation", [])) if isinstance(normalization, Mapping) else []
    )
    truncation = (
        dict(normalization.get("truncation", {})) if isinstance(normalization, Mapping) else {}
    )

    for key in ("session_id", "turn_id"):
        value = bounded.get(key)
        if not isinstance(value, str):
            continue
        raw = value.encode("utf-8", "surrogatepass")
        if _unsafe_text(value) or len(raw) > MAX_IDENTIFIER_BYTES:
            bounded[key] = "sha256:" + _sha256_bytes(raw)
            truncation[f"{key}_bytes"] = True
            degradation.append(f"{key}_hashed")

    model = bounded.get("model")
    if isinstance(model, str):
        raw = model.encode("utf-8", "surrogatepass")
        if _unsafe_text(model):
            bounded["model"] = "sha256:" + _sha256_bytes(raw)
            truncation["model_bytes"] = True
            degradation.append("model_hashed")
        elif len(raw) > MAX_IDENTIFIER_BYTES:
            bounded["model"], _ = _utf8_prefix(model, MAX_IDENTIFIER_BYTES)
            truncation["model_bytes"] = True
            degradation.append("model_truncated")
    bounded["normalization"] = {
        "degradation": sorted(set(degradation)),
        "truncation": {key: True for key in sorted(truncation) if truncation[key]},
    }
    return bounded


def _alias(payload: Mapping[str, object], logical: str) -> tuple[object | None, bool]:
    present = [(name, payload[name]) for name in _ALIASES[logical] if name in payload]
    if not present:
        return None, False
    first = present[0][1]
    if any(value != first for _, value in present[1:]):
        return None, True
    return first, False


def _normalize_event_contract(
    client: str,
    payload: Mapping[str, object],
) -> dict[str, Any] | None:
    if client not in _CLIENT_EVENTS or not isinstance(payload, Mapping):
        return None
    values: dict[str, object | None] = {}
    for logical in _ALIASES:
        value, conflict = _alias(payload, logical)
        if conflict:
            return None
        values[logical] = value
    event = values["event"]
    session_id = values["session_id"]
    if not isinstance(event, str) or not isinstance(session_id, str) or not session_id:
        return None
    contract = _CLIENT_EVENTS[client].get(event)
    if contract is None:
        return None
    trigger = values["trigger"]
    source = values["source"]
    if "trigger" in contract:
        if trigger not in contract["trigger"] or source is not None:
            return None
    elif trigger is not None:
        return None
    if "source" in contract:
        if source not in contract["source"] or trigger is not None:
            return None
    elif source is not None:
        return None
    optional = ("turn_id", "cwd", "transcript_path", "model")
    if any(values[name] is not None and not isinstance(values[name], str) for name in optional):
        return None
    return _bound_event_identifiers(
        {
            "contract_version": EVENT_CONTRACT_VERSION,
            "client": client,
            "event": event,
            "session_id": session_id,
            "turn_id": values["turn_id"],
            "trigger": trigger,
            "source": source,
            "cwd": values["cwd"],
            "transcript_path": values["transcript_path"],
            "model": values["model"],
        }
    )


def _adapt_claude_event(payload: Mapping[str, object]) -> dict[str, Any] | None:
    return _normalize_event_contract("claude", payload)


def _adapt_codex_event(payload: Mapping[str, object]) -> dict[str, Any] | None:
    return _normalize_event_contract("codex", payload)


_INPUT_ADAPTERS = {
    "claude": _adapt_claude_event,
    "codex": _adapt_codex_event,
}


def normalize_event(client: str, payload: Mapping[str, object]) -> dict[str, Any] | None:
    """Map one pinned client envelope to the versioned content-free contract."""
    adapter = _INPUT_ADAPTERS.get(client)
    if adapter is None or not isinstance(payload, Mapping):
        return None
    return adapter(payload)


def resolve_home(client: str, environ: Mapping[str, str] | None = None) -> Path:
    env = os.environ if environ is None else environ
    shared = env.get("EXOMEM_HOOK_HOME")
    if shared:
        return Path(shared).expanduser()
    if client == "codex":
        return Path(env.get("CODEX_HOME") or (Path.home() / ".codex")).expanduser()
    if client == "claude":
        return Path(env.get("CLAUDE_CONFIG_DIR") or (Path.home() / ".claude")).expanduser()
    raise ValueError(f"unsupported client: {client}")


def client_state_root(home: Path, client: str) -> Path:
    return Path(home) / ".cache" / "exomem-continuation" / client


def session_state_dir(home: Path, client: str, session_id: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9._-]+", "-", session_id).strip("-._") or "session"
    safe, _ = _utf8_prefix(safe, 48)
    digest = _sha256_bytes(f"{client}\0{session_id}".encode())[:20]
    return client_state_root(home, client) / f"{safe}-{digest}"


def activation_token_path(home: Path, client: str, session_id: str) -> Path:
    """Where the retrieve hook's continuity token lives for one session.

    Dot-prefixed, so the prune scan below — which skips every name beginning with
    a dot — never mistakes the token directory for an expired session entry.

    The name is a readable stem plus the SAME 20-hex `client\0session_id` digest
    `session_state_dir` above uses, so the token keyspace partitions exactly the
    sessions the checkpoint keyspace does. The sanitised stem alone does not:
    `abc-123`, `abc/123` and `abc 123` collapse onto one spelling, and any two
    long ids sharing a prefix collapse onto one more.

    Kept identical in `exomem_retrieve_nudge.py`, which writes the token: two
    standalone hook scripts cannot import each other, and
    `tests/test_retrieve_nudge_working_set.py` asserts the two derivations agree.
    """
    safe = re.sub(r"[^A-Za-z0-9._-]+", "-", str(session_id or "")).strip("-._")
    digest = _sha256_bytes(
        f"{client}\0{session_id}".encode("utf-8", "surrogatepass")
    )[:20]
    return (
        client_state_root(home, client)
        / ".activation"
        / f"{(safe or 'session')[:48]}-{digest}.token"
    )


def _rearm_nudges(home: Path, session_id: str) -> None:
    """Re-arm the once-per-session full nudge texts after a lifecycle event.

    The capture and retrieve hooks send their full text once per session and a short
    line afterwards, tracked by a stamp file each. A compaction rewrites the context
    that text lived in, so the next fire must be the full one again. The names mirror
    `_cooldown_ok` in `exomem_capture_nudge.py` and `exomem_retrieve_nudge.py`
    (`tests/test_nudge_diet.py` asserts the derivations agree). Never raises.
    """
    state_dir = Path(home) / ".cache" / "exomem-nudge"
    for name in (
        re.sub(r"[^A-Za-z0-9_.-]", "_", session_id or "default")[:128],
        "retrieve_" + re.sub(r"[^A-Za-z0-9_.-]", "_", session_id or "default")[:120],
        # The client-wide stamp too: it only dedupes a FRESH session, and a session
        # that just compacted is one again.
        "retrieve_global",
    ):
        try:
            (state_dir / name).unlink()
        except OSError:
            pass


def _clear_activation_token(home: Path, client: str, session_id: str) -> None:
    """Drop this session's continuity token. Called on EVERY lifecycle event the
    client delivers, because every one of them ends the run of turns the token
    described: a compaction rewrites the context it was minted against, and a
    session boundary starts a new one.

    Never raises and never reports: a token that outlives its session is only
    ever ignored by the server as stale, and a token that is dropped early only
    costs the next turn its qualifier.
    """
    try:
        unlink_nudge_file(activation_token_path(home, client, session_id))
    except (OSError, ValueError):
        pass


def _state_root_binding(home: Path, client: str) -> str:
    value = str(client_state_root(home, client).expanduser().absolute())
    return _sha256_bytes(value.encode("utf-8", "surrogatepass"))


def _safe_regular_fd(path: Path) -> int:
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    if os.name != "nt":
        flags |= getattr(os, "O_NONBLOCK", 0)
    fd = os.open(path, flags)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise OSError("not a regular file")
        return fd
    except BaseException:
        os.close(fd)
        raise


def _path_binding_with_reason(path: Path, home: Path) -> tuple[dict[str, str], str | None]:
    absolute_text = str(path.absolute())
    try:
        relative = path.absolute().relative_to(home.absolute()).as_posix()
    except ValueError:
        return {
            "kind": "sha256",
            "value": _sha256_bytes(absolute_text.encode("utf-8", "surrogatepass")),
        }, None
    raw = relative.encode("utf-8", "surrogatepass")
    parts = relative.split("/")
    if (
        _unsafe_text(relative)
        or relative.startswith(("/", "\\"))
        or "\\" in relative
        or not parts
        or any(part in {"", ".", ".."} for part in parts)
    ):
        return {"kind": "sha256", "value": _sha256_bytes(raw)}, "unsafe"
    if len(raw) > MAX_PATH_BYTES:
        return {"kind": "sha256", "value": _sha256_bytes(raw)}, "truncated"
    return {"kind": "relative", "value": relative}, None


def _path_binding(path: Path, home: Path) -> dict[str, str]:
    return _path_binding_with_reason(path, home)[0]


def _profile_transcript_with_truncation(
    path_value: str | None,
    home: Path,
) -> tuple[dict[str, Any], list[str], dict[str, bool]]:
    if not path_value:
        return {"available": False}, ["transcript_unavailable"], {}
    path = Path(path_value).expanduser()
    binding, binding_reason = _path_binding_with_reason(path, home)
    degradation = ["transcript_path_hashed"] if binding_reason == "unsafe" else []
    truncation = {"transcript_path_bytes": True} if binding_reason == "truncated" else {}
    try:
        fd = _safe_regular_fd(path)
        try:
            info = os.fstat(fd)
            offset = max(0, info.st_size - TRANSCRIPT_SLICE_BYTES)
            os.lseek(fd, offset, os.SEEK_SET)
            raw = os.read(fd, TRANSCRIPT_SLICE_BYTES)
        finally:
            os.close(fd)
    except OSError:
        return (
            {"available": False, "path": binding},
            [*degradation, "transcript_unavailable"],
            truncation,
        )
    return (
        {
            "available": True,
            "path": binding,
            "observed_size": info.st_size,
            "observed_mtime_ns": info.st_mtime_ns,
            "slice_offset": offset,
            "slice_length": len(raw),
            "slice_sha256": _sha256_bytes(raw),
        },
        degradation,
        truncation,
    )


def profile_transcript(path_value: str | None, home: Path) -> tuple[dict[str, Any], list[str]]:
    transcript, degradation, _truncation = _profile_transcript_with_truncation(path_value, home)
    return transcript, degradation


def _git_environment() -> dict[str, str]:
    allowed = ("PATH", "PATHEXT", "SYSTEMROOT", "WINDIR", "COMSPEC", "TMPDIR", "TEMP", "TMP")
    environment = {name: os.environ[name] for name in allowed if os.environ.get(name)}
    environment.update(
        {
            "GIT_CONFIG_GLOBAL": os.devnull,
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_OPTIONAL_LOCKS": "0",
            "GIT_TERMINAL_PROMPT": "0",
            "LC_ALL": "C",
        }
    )
    return environment


def _git_probe(cwd: Path, *args: str) -> tuple[str | None, int | None]:
    try:
        result = subprocess.run(
            [
                "git",
                "-c",
                "core.fsmonitor=false",
                "-c",
                "core.hooksPath=",
                "-C",
                str(cwd),
                *args,
            ],
            capture_output=True,
            text=True,
            # Pinned, not inherited: without it the pipe is decoded with
            # the host's active code page, and git happily emits a branch
            # name or a repository path this hook cannot spell in cp1252.
            # The resulting UnicodeDecodeError is raised inside subprocess's
            # reader, so no `except OSError` here would have caught it.
            # `replace` because a checkpoint hook must degrade, never abort
            # the session it is recording.
            encoding="utf-8",
            errors="replace",
            env=_git_environment(),
            timeout=GIT_TIMEOUT_SECONDS,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None, None
    value = result.stdout.rstrip("\r\n") if result.returncode == 0 else None
    return value, result.returncode


def _git(cwd: Path, *args: str) -> str | None:
    value, returncode = _git_probe(cwd, *args)
    return value if returncode == 0 else None


def _bounded_path(value: str) -> tuple[str, bool]:
    return _utf8_prefix(value.replace("\\", "/"), MAX_PATH_BYTES)


def _bounded_basename(value: str) -> tuple[str, bool, bool]:
    raw = value.encode("utf-8", "surrogatepass")
    if not value or value in {".", ".."} or "/" in value or "\\" in value or _unsafe_text(value):
        return "sha256:" + _sha256_bytes(raw), True, True
    bounded, truncated = _utf8_prefix(value, MAX_PATH_BYTES)
    return bounded, truncated, False


def _parse_porcelain_z(raw: str) -> list[str]:
    """Parse porcelain v1 -z records, including paired rename/copy paths."""
    records = raw.split("\0")
    paths: list[str] = []
    index = 0
    while index < len(records):
        record = records[index]
        index += 1
        if len(record) < 4 or record[2] != " ":
            continue
        status = record[:2]
        paths.append(record[3:])
        if ("R" in status or "C" in status) and index < len(records):
            paired = records[index]
            index += 1
            if paired:
                paths.append(paired)
    return paths


def _profile_workspace_with_root(
    cwd_value: str | None,
) -> tuple[dict[str, Any], set[str], dict[str, bool], list[str], Path | None]:
    truncation: dict[str, bool] = {}
    degradation: list[str] = []
    if not cwd_value:
        return {"available": False}, set(), truncation, ["cwd_unavailable", "non_git"], None
    cwd = Path(cwd_value).expanduser()
    root_raw = _git(cwd, "rev-parse", "--show-toplevel")
    if not root_raw:
        name, cut, hashed = _bounded_basename(cwd.name)
        if cut:
            truncation["workspace_name"] = True
        if hashed:
            degradation.append("workspace_name_hashed")
        return (
            {
                "available": False,
                "cwd_name": name,
                "cwd_sha256": _sha256_bytes(str(cwd.absolute()).encode("utf-8", "surrogatepass")),
            },
            set(),
            truncation,
            ["non_git"],
            None,
        )
    root = Path(root_raw)
    head = _git(root, "rev-parse", "HEAD")
    branch, branch_code = _git_probe(root, "symbolic-ref", "--quiet", "--short", "HEAD")
    if branch_code == 0:
        detached: bool | None = False
        if branch is not None:
            if _unsafe_text(branch):
                branch = "sha256:" + _sha256_bytes(branch.encode("utf-8", "surrogatepass"))
                truncation["branch_bytes"] = True
                degradation.append("git_branch_hashed")
            else:
                branch, cut = _bounded_path(branch)
                if cut:
                    truncation["branch_bytes"] = True
                    degradation.append("git_branch_truncated")
    elif branch_code == 1:
        detached = True
    else:
        detached = None
        degradation.append("git_branch_unavailable")
    dirty_raw, status_code = _git_probe(
        root,
        "status",
        "--porcelain=v1",
        "-z",
        "--untracked-files=all",
    )
    if status_code != 0:
        dirty_raw = ""
        degradation.append("git_status_unavailable")
    all_dirty: list[str] = []
    for value in _parse_porcelain_z(dirty_raw or ""):
        if _unsafe_text(value) or "\\" in value:
            truncation["dirty_path_unsafe"] = True
            degradation.append("dirty_path_unsafe")
            continue
        # git marks a directory it will not descend into - a nested repository,
        # such as a .claude/worktrees/ agent worktree - with a trailing slash.
        # Keep the path and drop the marker so the entry satisfies the same
        # relative-path contract the reader enforces.
        value = value.rstrip("/")
        value, cut = _bounded_path(value)
        if cut:
            truncation["dirty_path_bytes"] = True
        if not value:
            continue
        # Never emit a path the validator would reject; bounding can also cut a
        # path into a shape that no longer satisfies the contract.
        if not _safe_relative_path(value):
            truncation["dirty_path_unsafe"] = True
            degradation.append("dirty_path_unsafe")
            continue
        if value not in all_dirty:
            all_dirty.append(value)
    all_dirty.sort()
    artifact_dirty = {value for value in all_dirty if _allowed_artifact_relative(value)}
    dirty = list(all_dirty)
    if len(dirty) > MAX_DIRTY_PATHS:
        dirty = dirty[:MAX_DIRTY_PATHS]
        truncation["dirty_paths"] = True
    root_name, cut, hashed = _bounded_basename(root.name)
    if cut:
        truncation["workspace_name"] = True
    if hashed:
        degradation.append("workspace_name_hashed")
    workspace = {
        "available": True,
        "root": root_name,
        "root_sha256": _sha256_bytes(str(root.absolute()).encode("utf-8", "surrogatepass")),
        "branch": branch,
        "detached": detached,
        "head": head,
        "dirty_paths": dirty,
    }
    if head is None:
        degradation.append("git_head_unavailable")
    return workspace, set(dirty) | artifact_dirty, truncation, degradation, root


def profile_workspace(
    cwd_value: str | None,
) -> tuple[dict[str, Any], set[str], dict[str, bool], list[str]]:
    workspace, dirty, truncation, degradation, _root = _profile_workspace_with_root(cwd_value)
    return workspace, dirty, truncation, degradation


_FIXED_ARTIFACTS = (
    ".superpowers/sdd/progress.md",
    ".task/TASK.md",
    ".task/RESULT.md",
)


def _allowed_artifact_relative(value: str) -> bool:
    if _unsafe_text(value):
        return False
    if value in _FIXED_ARTIFACTS:
        return True
    if "\\" in value:
        return False
    parts = value.split("/")
    return (
        len(parts) == 4
        and parts[:2] == ["openspec", "changes"]
        and parts[2] not in {"", ".", ".."}
        and parts[3] == "tasks.md"
    )


def _artifact_candidate_relatives(
    root: Any,
    dirty_paths: set[str],
) -> tuple[list[str], bool, bool, bool]:
    dirty_candidates = sorted(
        value
        for value in dirty_paths
        if value.startswith("openspec/changes/") and _allowed_artifact_relative(value)
    )
    dirty_truncated = len(dirty_candidates) > MAX_DIRTY_ARTIFACT_CANDIDATES
    candidates = dirty_candidates[:MAX_DIRTY_ARTIFACT_CANDIDATES] + list(_FIXED_ARTIFACTS)
    truncated = False
    unsafe = False
    fallback: list[tuple[int, str]] = []
    try:
        with _open_secure_child_directory(root, "openspec", create=False) as openspec:
            with _open_secure_child_directory(openspec, "changes", create=False) as changes:
                entries, truncated = _list_directory_bounded(
                    changes, MAX_ARTIFACT_METADATA_CANDIDATES
                )
                for name in entries:
                    try:
                        _validate_child_name(name)
                        if _unsafe_text(name) or name in {".", ".."}:
                            unsafe = True
                            continue
                        mode = _existing_kind(changes, name)
                    except OSError:
                        unsafe = True
                        continue
                    if mode is not None and stat.S_ISDIR(mode):
                        relative = f"openspec/changes/{name}/tasks.md"
                        try:
                            with _open_secure_child_directory(
                                changes, name, create=False
                            ) as change:
                                fd = _open_secure_file_at(change, "tasks.md", os.O_RDONLY, 0o600)
                                try:
                                    info = os.fstat(fd)
                                finally:
                                    os.close(fd)
                                if not _same_directory_entry(changes, name, change):
                                    unsafe = True
                                    continue
                                fallback.append((info.st_mtime_ns, relative))
                        except FileNotFoundError:
                            continue
                        except OSError:
                            unsafe = True
                    elif mode is not None and stat.S_ISLNK(mode):
                        unsafe = True
    except FileNotFoundError:
        pass
    except OSError:
        unsafe = True
    candidates.extend(
        relative for _mtime, relative in sorted(fallback, key=lambda item: (-item[0], item[1]))
    )
    candidates = list(dict.fromkeys(candidates))
    if len(candidates) > MAX_ARTIFACT_CANDIDATE_READS:
        candidates = candidates[:MAX_ARTIFACT_CANDIDATE_READS]
        truncated = True
    return candidates, truncated, unsafe, dirty_truncated


def _read_regular_relative(
    root: Any,
    relative: str,
    limit: int,
) -> tuple[bytes, os.stat_result, bool]:
    if not _allowed_artifact_relative(relative):
        raise OSError("artifact path is outside the closed allowlist")
    parts = relative.split("/")
    with contextlib.ExitStack() as stack:
        directory = root
        retained: list[tuple[Any, str, Any]] = []
        for component in parts[:-1]:
            child = stack.enter_context(
                _open_secure_child_directory(directory, component, create=False)
            )
            retained.append((directory, component, child))
            directory = child
        fd = _open_secure_file_at(directory, parts[-1], os.O_RDONLY, 0o600)
        try:
            info = os.fstat(fd)
            raw = os.read(fd, limit)
            raced = not _same_file_entry(directory, parts[-1], fd)
        finally:
            os.close(fd)
        raced = raced or any(
            not _same_directory_entry(parent, name, child) for parent, name, child in retained
        )
        return raw, info, raced


def collect_artifacts(
    root: Path,
    *,
    dirty_paths: set[str],
) -> tuple[list[dict[str, Any]], dict[str, bool], list[str]]:
    truncation: dict[str, bool] = {}
    degradation: list[str] = []
    profiled: list[dict[str, Any]] = []
    try:
        root_context = _open_secure_directory(root, create=False)
        root_handle = root_context.__enter__()
    except OSError:
        return [], truncation, ["artifact_root_unavailable"]
    try:
        (
            candidates,
            candidates_truncated,
            candidates_unsafe,
            dirty_candidates_truncated,
        ) = _artifact_candidate_relatives(root_handle, dirty_paths)
        if candidates_truncated:
            truncation["artifact_candidates"] = True
            degradation.append("artifact_candidates_truncated")
        if candidates_unsafe:
            degradation.append("artifact_unsafe")
        if dirty_candidates_truncated:
            truncation["dirty_artifact_candidates"] = True
            degradation.append("dirty_artifact_candidates_truncated")
        for relative in candidates:
            try:
                raw, info, raced = _read_regular_relative(
                    root_handle,
                    relative,
                    MAX_ARTIFACT_READ_BYTES + 1,
                )
            except FileNotFoundError:
                continue
            except OSError:
                degradation.append("artifact_unsafe")
                continue
            if raced:
                degradation.append("artifact_raced")
                continue
            if len(raw) > MAX_ARTIFACT_READ_BYTES:
                degradation.append("artifact_oversized")
                truncation["artifact_bytes"] = True
                continue
            completed = 0
            incomplete = 0
            lines: list[int] = []
            for number, line in enumerate(raw.decode("utf-8", "replace").splitlines(), 1):
                match = _CHECKBOX.match(line)
                if not match:
                    continue
                if match.group(1).lower() == "x":
                    completed += 1
                else:
                    incomplete += 1
                    if len(lines) < MAX_INCOMPLETE_LINES:
                        lines.append(number)
            if incomplete > len(lines):
                truncation["incomplete_lines"] = True
            bounded, cut = _bounded_path(relative)
            if cut:
                truncation["artifact_path_bytes"] = True
            is_open = relative.startswith("openspec/changes/")
            is_dirty = relative in dirty_paths and is_open
            if is_open and not is_dirty and incomplete == 0:
                continue
            profiled.append(
                {
                    "path": bounded,
                    "size": info.st_size,
                    "mtime_ns": info.st_mtime_ns,
                    "sha256": _sha256_bytes(raw),
                    "completed_count": completed,
                    "incomplete_count": incomplete,
                    "incomplete_lines": lines,
                    "dirty": is_dirty,
                    "openspec": is_open,
                }
            )
    finally:
        root_context.__exit__(None, None, None)
    profiled.sort(
        key=lambda row: (
            0 if row["dirty"] and row["openspec"] else 1,
            -row["mtime_ns"],
            row["path"],
        )
    )
    kept: list[dict[str, Any]] = []
    openspec_count = 0
    for row in profiled:
        if row["openspec"]:
            if openspec_count >= MAX_OPENSPEC_ARTIFACTS:
                truncation["openspec_artifacts"] = True
                continue
            openspec_count += 1
        if len(kept) >= MAX_ARTIFACTS:
            truncation["artifacts"] = True
            break
        kept.append({key: value for key, value in row.items() if key not in {"dirty", "openspec"}})
    return kept, truncation, sorted(set(degradation))


def _trim_structural(structural: dict[str, Any]) -> dict[str, Any]:
    value = json.loads(json.dumps(structural))
    while len(_canonical_bytes({"structural": value})) > MAX_CHECKPOINT_BYTES - 1024:
        dirty = value.get("workspace", {}).get("dirty_paths", [])
        artifacts = value.get("artifacts", [])
        if dirty:
            dirty.pop()
            value.setdefault("truncation", {})["checkpoint_dirty_paths"] = True
        elif artifacts:
            artifacts.pop()
            value.setdefault("truncation", {})["checkpoint_artifacts"] = True
        else:
            break
    return value


def finalize_checkpoint(structural: dict[str, Any], *, observed_at_ns: int) -> dict[str, Any]:
    structural = _trim_structural(structural)
    structural_digest = _sha256_bytes(_canonical_bytes(structural))
    transcript = structural.get("transcript", {})
    identity = {
        "schema_version": structural.get("schema_version"),
        "client": structural.get("client"),
        "session_id": structural.get("session_id"),
        "turn_id": structural.get("turn_id"),
        "event": structural.get("event"),
        "trigger": structural.get("trigger"),
        "source": structural.get("source"),
        "transcript_size": transcript.get("observed_size", -1),
        "transcript_mtime_ns": transcript.get("observed_mtime_ns", -1),
        "transcript_slice_sha256": transcript.get("slice_sha256"),
        "structural_digest": structural_digest,
    }
    checkpoint_id = _sha256_bytes(_canonical_bytes(identity))
    event_order = [
        int(transcript.get("observed_mtime_ns", -1)),
        int(transcript.get("observed_size", -1)),
        int(observed_at_ns),
        checkpoint_id,
    ]
    return {
        "schema_version": SCHEMA_VERSION,
        "checkpoint_id": checkpoint_id,
        "structural_digest": structural_digest,
        "observed_at_ns": int(observed_at_ns),
        "event_order": event_order,
        "structural": structural,
    }


def encode_checkpoint(value: dict[str, Any]) -> bytes:
    encoded = _canonical_bytes(value) + b"\n"
    if len(encoded) > MAX_CHECKPOINT_BYTES:
        raise ValueError("checkpoint exceeds byte bound")
    return encoded


def build_checkpoint(
    event: Mapping[str, Any],
    home: Path,
    *,
    observed_at_ns: int | None = None,
) -> dict[str, Any]:
    event = _bound_event_identifiers(event)
    (
        transcript,
        transcript_degradation,
        transcript_truncation,
    ) = _profile_transcript_with_truncation(event.get("transcript_path"), home)
    (
        workspace,
        dirty,
        workspace_truncation,
        workspace_degradation,
        artifact_root,
    ) = _profile_workspace_with_root(event.get("cwd"))
    artifacts: list[dict[str, Any]] = []
    artifact_truncation: dict[str, bool] = {}
    artifact_degradation: list[str] = []
    if artifact_root is not None:
        artifacts, artifact_truncation, artifact_degradation = collect_artifacts(
            artifact_root, dirty_paths=dirty
        )
    normalization = event.get("normalization", {})
    normalization_degradation = normalization.get("degradation", [])
    normalization_truncation = normalization.get("truncation", {})
    structural = {
        "schema_version": SCHEMA_VERSION,
        "client": event["client"],
        "session_id": event["session_id"],
        "turn_id": event.get("turn_id"),
        "event": event["event"],
        "trigger": event.get("trigger"),
        "source": event.get("source"),
        "model": event.get("model"),
        "state_root_binding": _state_root_binding(home, event["client"]),
        "workspace": workspace,
        "transcript": transcript,
        "artifacts": artifacts,
        "degradation": sorted(
            set(
                list(normalization_degradation)
                + transcript_degradation
                + workspace_degradation
                + artifact_degradation
            )
        ),
        "truncation": {
            **normalization_truncation,
            **transcript_truncation,
            **workspace_truncation,
            **artifact_truncation,
        },
    }
    return finalize_checkpoint(
        structural,
        observed_at_ns=time.time_ns() if observed_at_ns is None else observed_at_ns,
    )


def _context_line(value: object) -> str:
    return str(value).replace("\r", " ").replace("\n", " ")


def render_continuation(checkpoint: Mapping[str, Any], *, status: str) -> str:
    structural = checkpoint["structural"]
    workspace = structural.get("workspace", {})
    transcript = structural.get("transcript", {})
    advisory = (
        "Reconcile these structural pointers with the compacted context: reopen cited "
        "artifacts and continue from evidence, inventing nothing. Capture a genuine durable "
        "stepping-stone through normal Exomem governance; otherwise no memory write. "
        "Advisory only; it does not prove capture completion."
    )
    content_budget = MAX_CONTEXT_BYTES - len(("\n" + advisory).encode("utf-8"))
    maximum_footer = (
        f"[continuation fields omitted: artifact pointers={MAX_ARTIFACTS}; "
        f"workspace=1; transcript binding=1; dirty paths={MAX_DIRTY_PATHS}]"
    )
    section_budget = content_budget - len(("\n" + maximum_footer).encode("utf-8"))
    lines = [
        "[Exomem continuation checkpoint]",
        f"checkpoint: {checkpoint['checkpoint_id']} ({status})",
    ]

    def append_if_fits(line: str) -> bool:
        candidate = "\n".join([*lines, line])
        if len(candidate.encode("utf-8")) > section_budget:
            return False
        lines.append(line)
        return True

    if structural.get("degradation"):
        append_if_fits("degraded: " + ", ".join(structural["degradation"]))
    if structural.get("truncation"):
        append_if_fits("truncated: " + ", ".join(sorted(structural["truncation"])))
    omissions: dict[str, int] = {}
    if workspace:
        if not append_if_fits(
            "workspace: "
            f"{_context_line(workspace.get('root') or workspace.get('cwd_name') or 'unavailable')} "
            f"branch={_context_line(workspace.get('branch'))} "
            f"head={_context_line(workspace.get('head'))}"
        ):
            omissions["workspace"] = 1
    if transcript.get("available"):
        if not append_if_fits(
            "transcript binding: "
            f"size={transcript.get('observed_size')} offset={transcript.get('slice_offset')} "
            f"length={transcript.get('slice_length')} sha256={transcript.get('slice_sha256')}"
        ):
            omissions["transcript binding"] = 1
    omitted_artifacts = 0
    for artifact in structural.get("artifacts", []):
        if not append_if_fits(
            f"artifact: {_context_line(artifact.get('path'))} "
            f"incomplete={artifact.get('incomplete_count')} "
            f"lines={artifact.get('incomplete_lines')}"
        ):
            omitted_artifacts += 1
    if omitted_artifacts:
        omissions["artifact pointers"] = omitted_artifacts
    dirty = workspace.get("dirty_paths") or []
    if dirty:
        shown: list[str] = []
        for item in dirty:
            candidate = shown + [_context_line(item)]
            line = "dirty paths: " + ", ".join(candidate)
            if len("\n".join([*lines, line]).encode("utf-8")) > section_budget:
                break
            shown = candidate
        if shown:
            append_if_fits("dirty paths: " + ", ".join(shown))
        if len(shown) < len(dirty):
            omissions["dirty paths"] = len(dirty) - len(shown)
    if omissions:
        order = ("artifact pointers", "workspace", "transcript binding", "dirty paths")
        footer = (
            "[continuation fields omitted: "
            + "; ".join(f"{name}={omissions[name]}" for name in order if name in omissions)
            + "]"
        )
        lines.append(footer)
    return "\n".join(lines) + "\n" + advisory


def _windows_open_path(
    path: Path,
    *,
    directory: bool,
    access: int = 0x80,
    share: int = 0x3,
    creation: int = 3,
) -> int:
    """Return a non-reparse Win32 handle for one exact path entry."""
    import ctypes
    from ctypes import wintypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    create_file = kernel32.CreateFileW
    create_file.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.LPVOID,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.HANDLE,
    ]
    create_file.restype = wintypes.HANDLE
    flags = 0x00200000  # FILE_FLAG_OPEN_REPARSE_POINT
    if directory:
        flags |= 0x02000000  # FILE_FLAG_BACKUP_SEMANTICS
    handle = create_file(str(path), access, share, None, creation, flags, None)
    invalid = wintypes.HANDLE(-1).value
    if handle == invalid:
        error = ctypes.get_last_error()
        if error in {2, 3}:
            raise FileNotFoundError(error, f"cannot safely open {path.name}")
        if error in {80, 183}:
            raise FileExistsError(error, f"path already exists: {path.name}")
        raise OSError(error, f"cannot safely open {path.name}")

    class _AttributeTagInfo(ctypes.Structure):
        _fields_ = [("attributes", wintypes.DWORD), ("reparse_tag", wintypes.DWORD)]

    info = _AttributeTagInfo()
    try:
        get_info = kernel32.GetFileInformationByHandleEx
        get_info.argtypes = [wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD]
        get_info.restype = wintypes.BOOL
        if not get_info(handle, 9, ctypes.byref(info), ctypes.sizeof(info)):
            raise OSError(ctypes.get_last_error(), f"cannot inspect {path.name}")
        if info.attributes & 0x400:  # FILE_ATTRIBUTE_REPARSE_POINT
            raise OSError("reparse points are not allowed")
        is_directory = bool(info.attributes & 0x10)
        if is_directory != directory:
            raise OSError("unexpected path type")
    except BaseException:
        kernel32.CloseHandle(handle)
        raise
    return int(handle)


def _windows_close_handle(handle: int) -> None:
    import ctypes

    ctypes.WinDLL("kernel32", use_last_error=True).CloseHandle(handle)


def _windows_final_path(handle: int) -> str:
    import ctypes
    from ctypes import wintypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    get_path = kernel32.GetFinalPathNameByHandleW
    get_path.argtypes = [wintypes.HANDLE, wintypes.LPWSTR, wintypes.DWORD, wintypes.DWORD]
    get_path.restype = wintypes.DWORD
    size = get_path(handle, None, 0, 0)
    if not size:
        raise OSError(ctypes.get_last_error(), "cannot resolve retained Windows handle")
    buffer = ctypes.create_unicode_buffer(size + 1)
    written = get_path(handle, buffer, len(buffer), 0)
    if not written or written >= len(buffer):
        raise OSError(ctypes.get_last_error(), "cannot resolve retained Windows handle")
    return buffer.value


def _windows_handle_identity(handle: int) -> tuple[int, int, int]:
    import ctypes
    from ctypes import wintypes

    class _FileInfo(ctypes.Structure):
        _fields_ = [
            ("attributes", wintypes.DWORD),
            ("creation_time", wintypes.FILETIME),
            ("access_time", wintypes.FILETIME),
            ("write_time", wintypes.FILETIME),
            ("volume_serial", wintypes.DWORD),
            ("size_high", wintypes.DWORD),
            ("size_low", wintypes.DWORD),
            ("links", wintypes.DWORD),
            ("file_index_high", wintypes.DWORD),
            ("file_index_low", wintypes.DWORD),
        ]

    info = _FileInfo()
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    get_info = kernel32.GetFileInformationByHandle
    get_info.argtypes = [wintypes.HANDLE, ctypes.POINTER(_FileInfo)]
    get_info.restype = wintypes.BOOL
    if not get_info(handle, ctypes.byref(info)):
        raise OSError(ctypes.get_last_error(), "cannot identify retained Windows handle")
    return info.volume_serial, info.file_index_high, info.file_index_low


def _windows_delete_directory_handle(handle: int) -> None:
    import ctypes
    from ctypes import wintypes

    class _Disposition(ctypes.Structure):
        _fields_ = [("delete", wintypes.BOOLEAN)]

    disposition = _Disposition(True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    set_info = kernel32.SetFileInformationByHandle
    set_info.argtypes = [wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD]
    set_info.restype = wintypes.BOOL
    if not set_info(handle, 4, ctypes.byref(disposition), ctypes.sizeof(disposition)):
        raise OSError(ctypes.get_last_error(), "handle-relative Windows deletion failed")


class _SecureDirectory:
    def __init__(
        self,
        path: Path,
        *,
        fd: int | None = None,
        windows_handles: list[int] | None = None,
    ) -> None:
        self.path = path
        self.fd = fd
        self.windows_handles = windows_handles or []

    @property
    def windows_handle(self) -> int:
        if not self.windows_handles:
            raise OSError("secure Windows directory handle is unavailable")
        return self.windows_handles[-1]

    def close(self) -> None:
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None
        while self.windows_handles:
            _windows_close_handle(self.windows_handles.pop())


def _open_posix_directory(path: Path, *, create: bool, mode: int) -> int:
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    current_fd = os.open(path.anchor or "/", flags)
    try:
        for part in path.parts[1:]:
            try:
                child_fd = os.open(part, flags, dir_fd=current_fd)
            except FileNotFoundError:
                if not create:
                    raise
                os.mkdir(part, mode=mode, dir_fd=current_fd)
                child_fd = os.open(part, flags, dir_fd=current_fd)
            if not stat.S_ISDIR(os.fstat(child_fd).st_mode):
                os.close(child_fd)
                raise OSError("non-directory path component")
            os.close(current_fd)
            current_fd = child_fd
        return current_fd
    except BaseException:
        os.close(current_fd)
        raise


@contextlib.contextmanager
def _open_secure_directory(
    path: Path,
    *,
    create: bool,
    mode: int = 0o700,
) -> Any:
    """Pin a non-reparse directory and every Windows ancestor for an operation."""
    absolute = path.expanduser().absolute()
    if os.name != "nt":
        directory = _SecureDirectory(
            absolute,
            fd=_open_posix_directory(absolute, create=create, mode=mode),
        )
    else:
        handles: list[int] = []
        current = Path(absolute.anchor)
        try:
            handles.append(_windows_open_path(current, directory=True))
            for part in absolute.parts[1:]:
                current /= part
                try:
                    handles.append(_windows_open_path(current, directory=True))
                except FileNotFoundError:
                    if not create:
                        raise
                    current.mkdir(mode=mode)
                    handles.append(_windows_open_path(current, directory=True))
            directory = _SecureDirectory(absolute, windows_handles=handles)
        except BaseException:
            while handles:
                _windows_close_handle(handles.pop())
            raise
    try:
        yield directory
    finally:
        directory.close()


def _ensure_secure_dir(path: Path, mode: int = 0o700) -> int | None:
    """Create/open a directory safely; retain a duplicated POSIX descriptor."""
    with _open_secure_directory(path, create=True, mode=mode) as directory:
        return os.dup(directory.fd) if directory.fd is not None else None


def _validate_child_name(name: str) -> None:
    if not name or Path(name).name != name or "/" in name or "\\" in name:
        raise OSError("state operations require one child basename")


def _normalized_windows_path(value: str) -> str:
    if value.startswith("\\\\?\\UNC\\"):
        value = "\\\\" + value[8:]
    elif value.startswith("\\\\?\\"):
        value = value[4:]
    return value.rstrip("\\/").replace("/", "\\").casefold()


@contextlib.contextmanager
def _open_secure_child_directory(
    parent: _SecureDirectory,
    name: str,
    *,
    create: bool,
    mode: int = 0o700,
    delete_access: bool = False,
) -> Any:
    """Open one child relative to a retained, already-validated parent."""
    _validate_child_name(name)
    child_path = parent.path / name
    if os.name != "nt":
        flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
        try:
            fd = os.open(name, flags, dir_fd=parent.fd)
        except FileNotFoundError:
            if not create:
                raise
            os.mkdir(name, mode=mode, dir_fd=parent.fd)
            fd = os.open(name, flags, dir_fd=parent.fd)
        directory = _SecureDirectory(child_path, fd=fd)
    else:
        parent_final = _normalized_windows_path(_windows_final_path(parent.windows_handle))
        access = 0x80 | (0x00010000 if delete_access else 0)
        share = 0x3
        try:
            handle = _windows_open_path(
                child_path,
                directory=True,
                access=access,
                share=share,
            )
        except FileNotFoundError:
            if not create:
                raise
            os.mkdir(child_path, mode=mode)
            handle = _windows_open_path(
                child_path,
                directory=True,
                access=access,
                share=share,
            )
        child_final = _normalized_windows_path(_windows_final_path(handle))
        if child_final.rsplit("\\", 1)[0] != parent_final:
            _windows_close_handle(handle)
            raise OSError("Windows child escaped its retained parent")
        directory = _SecureDirectory(child_path, windows_handles=[handle])
    try:
        yield directory
    finally:
        directory.close()


def _same_directory_entry(
    parent: _SecureDirectory,
    name: str,
    child: _SecureDirectory,
) -> bool:
    return _directory_entry_identity(parent, name) == _directory_identity(child)


def _directory_identity(directory: _SecureDirectory) -> tuple[object, ...]:
    if os.name != "nt":
        retained = os.fstat(directory.fd)
        return "posix", retained.st_dev, retained.st_ino
    return ("windows", *_windows_handle_identity(directory.windows_handle))


def _require_private_state_directory(directory: _SecureDirectory) -> None:
    if os.name == "nt":
        return
    mode = stat.S_IMODE(os.fstat(directory.fd).st_mode)
    if mode != 0o700:
        raise OSError(f"state directory permissions are too broad: {mode:04o}")


def unsafe_trusted_directory_ancestors(path: Path) -> list[tuple[str, str]]:
    """Every ancestor of `path` (and `path`) that fails the trusted-directory rule.

    Returns `[(offending path, reason)]`, nearest-root first, empty when the whole
    chain is trusted. Separated from the raise so a preflight can report the full
    chain before anything is attempted: the guard rejects any ancestor, but the
    caller only ever learns about one path per run, and on a `umask 0002` box
    (the Debian/Ubuntu default) three separate directories fail in sequence.
    Fixing them one failed run at a time is three installs to get one.
    """
    if os.name == "nt":
        return []
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    handles: list[int] = []
    offenders: list[tuple[str, str]] = []
    absolute = Path(path).absolute()
    try:
        current = os.open(absolute.anchor or "/", flags)
        handles.append(current)
        parts = absolute.parts[1:]
        walked = Path(absolute.anchor or "/")
        for index, part in enumerate(parts):
            child = os.open(part, flags, dir_fd=current)
            handles.append(child)
            current = child
            walked = walked / part
            info = os.fstat(child)
            mode = stat.S_IMODE(info.st_mode)
            if index == len(parts) - 1:
                if info.st_uid != os.geteuid():
                    offenders.append((str(walked), "owned by another user"))
                elif mode & 0o022:
                    offenders.append((str(walked), f"group/other-writable ({mode:04o})"))
            else:
                sticky_trusted = bool(mode & stat.S_ISVTX) and info.st_uid in {
                    0,
                    os.geteuid(),
                }
                if mode & 0o022 and not sticky_trusted:
                    offenders.append((str(walked), f"group/other-writable ({mode:04o})"))
    finally:
        while handles:
            os.close(handles.pop())
    return offenders


def trusted_directory_remediation(offenders: list[tuple[str, str]]) -> str:
    """A single command that clears every offending path in one go."""
    return "chmod g-w,o-w " + " ".join(path for path, _reason in offenders)


def _require_trusted_directory(directory: _SecureDirectory) -> None:
    """Reject hook/config directories writable by another local principal."""
    if os.name == "nt":
        return
    offenders = unsafe_trusted_directory_ancestors(directory.path)
    if offenders:
        detail = "; ".join(f"{path} ({reason})" for path, reason in offenders)
        leaf = str(Path(directory.path).absolute())
        # Name the path that actually failed. Interpolating the leaf sent users
        # to chmod a directory that was already fine while the real offender —
        # an ancestor — went unnamed.
        scope = detail if offenders[-1][0] == leaf else f"{detail} (ancestor(s) of {leaf})"
        raise OSError(
            errno.EPERM,
            f"unsafe writable or foreign-owned directory: {scope}; "
            f"fix: {trusted_directory_remediation(offenders)}",
        )
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    handles: list[int] = []
    try:
        current = os.open(directory.path.anchor or "/", flags)
        handles.append(current)
        for part in directory.path.absolute().parts[1:]:
            child = os.open(part, flags, dir_fd=current)
            handles.append(child)
            current = child
        retained = os.fstat(directory.fd)
        reopened = os.fstat(current)
        if (retained.st_dev, retained.st_ino) != (reopened.st_dev, reopened.st_ino):
            raise OSError(errno.EPERM, "trusted directory identity changed")
    finally:
        while handles:
            os.close(handles.pop())


def _directory_entry_identity(
    parent: _SecureDirectory,
    name: str,
) -> tuple[object, ...] | None:
    try:
        if os.name != "nt":
            current = os.stat(name, dir_fd=parent.fd, follow_symlinks=False)
            if not stat.S_ISDIR(current.st_mode):
                return None
            return "posix", current.st_dev, current.st_ino
        current_handle = _windows_open_path(parent.path / name, directory=True)
        try:
            return "windows", *_windows_handle_identity(current_handle)
        finally:
            _windows_close_handle(current_handle)
    except OSError:
        return None


def _same_file_entry(directory: _SecureDirectory, name: str, fd: int) -> bool:
    try:
        if os.name != "nt":
            current = os.stat(name, dir_fd=directory.fd, follow_symlinks=False)
            retained = os.fstat(fd)
            return (
                stat.S_ISREG(current.st_mode)
                and current.st_dev == retained.st_dev
                and current.st_ino == retained.st_ino
            )
        import msvcrt

        current_handle = _windows_open_path(directory.path / name, directory=False)
        try:
            return _windows_handle_identity(current_handle) == _windows_handle_identity(
                msvcrt.get_osfhandle(fd)
            )
        finally:
            _windows_close_handle(current_handle)
    except OSError:
        return False


def _open_secure_file_at(
    directory: _SecureDirectory,
    name: str,
    flags: int,
    mode: int = 0o600,
) -> int:
    _validate_child_name(name)
    actual_flags = flags | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    if os.name != "nt":
        actual_flags |= getattr(os, "O_NONBLOCK", 0)
        fd = os.open(name, actual_flags, mode, dir_fd=directory.fd)
    else:
        import msvcrt

        access = 0x80000000  # GENERIC_READ
        if flags & os.O_RDWR:
            access = 0xC0000000  # GENERIC_READ | GENERIC_WRITE
        elif flags & os.O_WRONLY:
            access = 0x40000000  # GENERIC_WRITE
        if flags & os.O_CREAT and flags & os.O_EXCL:
            creation = 1  # CREATE_NEW
        elif flags & os.O_CREAT:
            creation = 4  # OPEN_ALWAYS
        else:
            creation = 3  # OPEN_EXISTING
        handle = _windows_open_path(
            directory.path / name,
            directory=False,
            access=access,
            creation=creation,
        )
        crt_flags = flags | getattr(os, "O_BINARY", 0)
        try:
            fd = msvcrt.open_osfhandle(handle, crt_flags)
        except BaseException:
            _windows_close_handle(handle)
            raise
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode):
        os.close(fd)
        raise OSError("state path is not a regular file")
    if flags & os.O_CREAT:
        try:
            os.fchmod(fd, mode)
        except (AttributeError, OSError):
            pass
    return fd


def _open_secure_file(path: Path, flags: int, mode: int = 0o600) -> int:
    with _open_secure_directory(path.parent, create=True) as directory:
        return _open_secure_file_at(directory, path.name, flags, mode)


def _existing_kind(directory: _SecureDirectory, name: str) -> int | None:
    _validate_child_name(name)
    try:
        if os.name == "nt":
            return os.lstat(directory.path / name).st_mode
        return os.stat(name, dir_fd=directory.fd, follow_symlinks=False).st_mode
    except FileNotFoundError:
        return None


def _windows_rename_at(
    directory: _SecureDirectory,
    source: str,
    destination: str,
    *,
    source_is_directory: bool,
    replace: bool,
) -> None:
    import ctypes
    from ctypes import wintypes

    source_handle = _windows_open_path(
        directory.path / source,
        directory=source_is_directory,
        access=0x00010000 | 0x80,  # DELETE | FILE_READ_ATTRIBUTES
        share=0x7,
    )
    try:
        # SetFileInformationByHandle's Win32 FILE_RENAME_INFO contract requires
        # RootDirectory to be NULL.  Keep the already-validated directory tree
        # pinned by its retained handles, but pass the destination as the absolute
        # final path of that retained directory rather than as a handle-relative
        # basename (which fails with ERROR_INVALID_PARAMETER on Windows 11).
        directory_path = _windows_final_path(directory.windows_handle).rstrip("\\/")
        destination_path = f"{directory_path}\\{destination}"
        encoded = destination_path.encode("utf-16-le")

        class _RenameHeader(ctypes.Structure):
            _fields_ = [
                ("replace", wintypes.BOOLEAN),
                ("root", wintypes.HANDLE),
                ("length", wintypes.DWORD),
            ]

        offset = _RenameHeader.length.offset + ctypes.sizeof(wintypes.DWORD)
        # FILE_RENAME_INFO's FileNameLength excludes the terminator, but the
        # FileName member itself must still be NUL-terminated.  Without these
        # two zero bytes Windows can consume adjacent memory as a filename
        # suffix and report success after renaming to the wrong path.
        buffer = ctypes.create_string_buffer(
            offset + len(encoded) + ctypes.sizeof(wintypes.WCHAR)
        )
        header = _RenameHeader.from_buffer(buffer)
        header.replace = bool(replace)
        header.root = wintypes.HANDLE()
        header.length = len(encoded)
        ctypes.memmove(ctypes.addressof(buffer) + offset, encoded, len(encoded))
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        rename = kernel32.SetFileInformationByHandle
        rename.argtypes = [wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD]
        rename.restype = wintypes.BOOL
        if not rename(source_handle, 3, buffer, len(buffer)):  # FileRenameInfo
            error = ctypes.get_last_error()
            if error in {5, 32}:
                raise PermissionError(error, "Windows entry is held open")
            raise OSError(error, "secure Windows rename failed")
    finally:
        _windows_close_handle(source_handle)


def _replace_at(directory: _SecureDirectory, source: str, destination: str) -> None:
    source_mode = _existing_kind(directory, source)
    destination_mode = _existing_kind(directory, destination)
    if source_mode is None or not stat.S_ISREG(source_mode):
        raise OSError("replacement source is not regular")
    if destination_mode is not None and not stat.S_ISREG(destination_mode):
        raise OSError("replacement destination is not regular")
    if os.name == "nt":
        _windows_rename_at(
            directory,
            source,
            destination,
            source_is_directory=False,
            replace=True,
        )
    else:
        os.replace(
            source,
            destination,
            src_dir_fd=directory.fd,
            dst_dir_fd=directory.fd,
        )
        os.fsync(directory.fd)


def _safe_replace(source: Path, destination: Path) -> None:
    if source.parent.absolute() != destination.parent.absolute():
        raise OSError("atomic replacement must remain in one directory")
    with _open_secure_directory(source.parent, create=True) as directory:
        _replace_at(directory, source.name, destination.name)


def _validate_nudge_parent(path: Path) -> None:
    """Validate existing ancestors before creating any advisory state."""
    current = Path(path).absolute()
    while True:
        try:
            with _open_secure_directory(current, create=False) as directory:
                _require_trusted_directory(directory)
            return
        except FileNotFoundError:
            if current == current.parent:
                raise
            current = current.parent


def _require_nudge_file(directory: _SecureDirectory, name: str, fd: int) -> os.stat_result:
    info = os.fstat(fd)
    if info.st_nlink != 1 or not _same_file_entry(directory, name, fd):
        raise OSError(errno.EPERM, "redirected nudge state file")
    if os.name != "nt" and (info.st_uid != os.geteuid() or info.st_mode & 0o022):
        raise OSError(errno.EPERM, "unsafe writable or foreign-owned nudge state file")
    return info


def validate_nudge_home(home: Path, client: str | None = None) -> None:
    """Read-only installation preflight for the selected profile's state chain."""
    home = Path(home).absolute()
    state = home / ".cache" / "exomem-nudge"
    continuation = home / ".cache" / "exomem-continuation"
    directories = [home, home / ".cache", state, continuation]
    if client is not None:
        directories.extend([continuation / client, continuation / client / ".activation"])
    for directory in directories:
        _validate_nudge_parent(directory)
    for path in (
        home / "exomem-retrieve-nudge.log",
        home / "exomem-capture-nudge.log",
        state / "pending-restart",
    ):
        try:
            with _open_secure_directory(path.parent, create=False) as directory:
                fd = _open_secure_file_at(directory, path.name, os.O_RDONLY)
                try:
                    _require_nudge_file(directory, path.name, fd)
                finally:
                    os.close(fd)
        except FileNotFoundError:
            pass


def read_nudge_file(path: Path, max_bytes: int, *, private: bool = False) -> bytes:
    with _open_secure_directory(path.parent, create=False) as directory:
        _require_trusted_directory(directory)
        fd = _open_secure_file_at(directory, path.name, os.O_RDONLY)
        try:
            info = _require_nudge_file(directory, path.name, fd)
            if private and os.name != "nt" and stat.S_IMODE(info.st_mode) != 0o600:
                raise OSError(errno.EPERM, "nudge state file is not private")
            raw = os.read(fd, max_bytes + 1)
            if len(raw) > max_bytes:
                raise OSError(errno.EFBIG, "oversized nudge state file")
            return raw
        finally:
            os.close(fd)


def unlink_nudge_file(path: Path) -> None:
    with _open_secure_directory(path.parent, create=False) as directory:
        _require_trusted_directory(directory)
        fd = _open_secure_file_at(directory, path.name, os.O_RDONLY)
        try:
            _require_nudge_file(directory, path.name, fd)
        finally:
            os.close(fd)
        _unlink_at(directory, path.name)


def write_nudge_file(path: Path, content: bytes, *, append: bool = False) -> None:
    """Private, no-follow advisory writes using the held-directory primitives."""
    path = Path(path).absolute()
    _validate_nudge_parent(path.parent)
    with _open_secure_directory(path.parent, create=True) as directory:
        _require_trusted_directory(directory)
        existing = _existing_kind(directory, path.name)
        if existing is not None:
            fd = _open_secure_file_at(
                directory, path.name, os.O_WRONLY | os.O_APPEND if append else os.O_RDONLY
            )
            try:
                _require_nudge_file(directory, path.name, fd)
                if append:
                    if os.name != "nt":
                        os.fchmod(fd, 0o600)
                    _write_all(fd, content)
                    return
            finally:
                os.close(fd)
        if append:
            fd = _open_secure_file_at(
                directory, path.name, os.O_WRONLY | os.O_APPEND | os.O_CREAT | os.O_EXCL
            )
            try:
                _write_all(fd, content)
            finally:
                os.close(fd)
            return
        temporary = f"{path.name}.tmp-{os.getpid()}-{secrets.token_hex(8)}"
        fd = _open_secure_file_at(
            directory, temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL
        )
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            _replace_at(directory, temporary, path.name)
        finally:
            _unlink_at(directory, temporary)


def _unlink_at(directory: _SecureDirectory, name: str) -> None:
    mode = _existing_kind(directory, name)
    if mode is None:
        return
    if not stat.S_ISREG(mode):
        raise OSError("refusing to unlink non-regular state")
    if os.name == "nt":
        os.unlink(directory.path / name)
    else:
        os.unlink(name, dir_fd=directory.fd)


def _safe_unlink(path: Path) -> None:
    with _open_secure_directory(path.parent, create=True) as directory:
        _unlink_at(directory, path.name)


class _AdvisoryLock:
    def __init__(
        self,
        path: Path,
        timeout: float,
        *,
        directory: _SecureDirectory | None = None,
        name: str | None = None,
    ) -> None:
        self.path = path
        self.directory = directory
        self.name = name
        self.timeout = timeout
        self.fd: int | None = None

    def __enter__(self) -> _AdvisoryLock:
        if self.directory is None:
            self.fd = _open_secure_file(self.path, os.O_RDWR | os.O_CREAT, 0o600)
        else:
            self.fd = _open_secure_file_at(
                self.directory,
                str(self.name),
                os.O_RDWR | os.O_CREAT,
                0o600,
            )
        if os.fstat(self.fd).st_size < 1:
            os.lseek(self.fd, 0, os.SEEK_SET)
            os.write(self.fd, b"\0")
            os.fsync(self.fd)
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                os.lseek(self.fd, 0, os.SEEK_SET)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(self.fd, msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except OSError as error:
                if error.errno not in {errno.EACCES, errno.EAGAIN, errno.EDEADLK}:
                    self.__exit__(None, None, None)
                    raise
                if time.monotonic() >= deadline:
                    self.__exit__(None, None, None)
                    raise TimeoutError(f"timed out acquiring {self.path.name}") from None
                time.sleep(0.005 + secrets.randbelow(5) / 1000)

    def __exit__(self, *_: object) -> None:
        if self.fd is None:
            return
        try:
            os.lseek(self.fd, 0, os.SEEK_SET)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.fd, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.fd, fcntl.LOCK_UN)
        except OSError:
            pass
        finally:
            os.close(self.fd)
            self.fd = None


def advisory_lock(path: Path, *, timeout: float = 0.5) -> _AdvisoryLock:
    return _AdvisoryLock(path, timeout)


def _advisory_lock_at(
    directory: _SecureDirectory,
    name: str,
    *,
    timeout: float = 0.5,
) -> _AdvisoryLock:
    return _AdvisoryLock(directory.path / name, timeout, directory=directory, name=name)


def _session_manifest(
    home: Path,
    client: str,
    session_id: str,
    created_at_ns: int,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "kind": "session",
        "client": client,
        "session_id": session_id,
        "state_name": session_state_dir(home, client, session_id).name,
        "state_root_binding": _state_root_binding(home, client),
        "created_at_ns": int(created_at_ns),
    }


def _valid_session_manifest(
    value: object,
    home: Path,
    client: str,
    state_name: str,
) -> bool:
    if not isinstance(value, dict) or set(value) != {
        "schema_version",
        "kind",
        "client",
        "session_id",
        "state_name",
        "state_root_binding",
        "created_at_ns",
    }:
        return False
    session_id = value.get("session_id")
    return (
        type(value.get("schema_version")) is int
        and value.get("schema_version") == SCHEMA_VERSION
        and value.get("kind") == "session"
        and value.get("client") == client
        and _bounded_safe_text(session_id)
        and value.get("state_name") == state_name
        and value.get("state_root_binding") == _state_root_binding(home, client)
        and session_state_dir(home, client, str(session_id)).name == state_name
        and type(value.get("created_at_ns")) is int
        and value["created_at_ns"] >= 0
    )


def _pending_session_name(state_name: str) -> str:
    _validate_child_name(state_name)
    return f".pending-{state_name}.json"


_STATE_NAME_TOKEN = r"[A-Za-z0-9._-]{1,80}-[0-9a-f]{20}"
_PENDING_CANONICAL = re.compile(rf"^\.pending-(?P<state>{_STATE_NAME_TOKEN})\.json$")
_PENDING_TEMP = re.compile(
    rf"^\.pending-(?P<state>{_STATE_NAME_TOKEN})\.tmp-[0-9]+-[0-9a-f]{{16}}$"
)


def _regular_file_info_at(directory: _SecureDirectory, name: str) -> os.stat_result | None:
    try:
        fd = _open_secure_file_at(directory, name, os.O_RDONLY, 0o600)
        try:
            info = os.fstat(fd)
            return info if stat.S_ISREG(info.st_mode) else None
        finally:
            os.close(fd)
    except OSError:
        return None


def _cleanup_pending_root_entry(
    root: _SecureDirectory,
    root_lock: _AdvisoryLock,
    home: Path,
    client: str,
    name: str,
    now_ns: int,
    *,
    target_state_name: str | None = None,
) -> None:
    temporary = _PENDING_TEMP.fullmatch(name)
    if temporary is not None:
        info = _regular_file_info_at(root, name)
        if info is None:
            return
        target_match = temporary.group("state") == target_state_name
        expired = now_ns - int(info.st_mtime_ns) > RETENTION_NS
        if target_match or expired:
            try:
                _unlink_at(root, name)
                if _existing_kind(root, name) is None:
                    _unregister_prune_catalog_entry(root, root_lock, name)
            except OSError:
                pass
        return
    canonical = _PENDING_CANONICAL.fullmatch(name)
    if canonical is None or target_state_name is not None:
        return
    state_name = canonical.group("state")
    pending, status_value = _load_pending_session_at(root, home, client, state_name)
    if status_value != "valid" or pending is None:
        return
    if _existing_kind(root, state_name) is not None:
        if not _published_session_matches_pending(
            root,
            home,
            client,
            state_name,
            pending,
        ):
            return
        try:
            _unlink_at(root, name)
            if _existing_kind(root, name) is None:
                _unregister_prune_catalog_entry(root, root_lock, name)
        except OSError:
            pass
        return
    if now_ns - int(pending["created_at_ns"]) > RETENTION_NS:
        try:
            _unlink_at(root, name)
            if _existing_kind(root, name) is None:
                _unregister_prune_catalog_entry(root, root_lock, name)
        except OSError:
            pass


def _published_session_matches_pending(
    root: _SecureDirectory,
    home: Path,
    client: str,
    state_name: str,
    pending: Mapping[str, Any],
) -> bool:
    """Prove a canonical pending record is redundant, without trusting its path."""
    try:
        context = _open_secure_child_directory(root, state_name, create=False)
        state = context.__enter__()
    except OSError:
        return False
    try:
        _require_private_state_directory(state)
        manifest, status_value = load_session_manifest_at(
            state,
            home,
            client,
            state_name,
        )
        return (
            status_value == "valid"
            and manifest == dict(pending)
            and _same_directory_entry(root, state_name, state)
        )
    except OSError:
        return False
    finally:
        context.__exit__(None, None, None)


def _cleanup_pending_temporaries_for_state(
    root: _SecureDirectory,
    root_lock: _AdvisoryLock,
    home: Path,
    client: str,
    state_name: str,
) -> None:
    deadline = time.monotonic() + MAX_PRUNE_LOCK_SECONDS
    try:
        names, _cursor, _exhausted, _inspected = _directory_window(
            root,
            cursor=0,
            limit=MAX_STATE_ENUM_ENTRIES,
            deadline=deadline,
        )
    except OSError:
        return
    now_ns = time.time_ns()
    for name in names:
        if time.monotonic() >= deadline:
            return
        _cleanup_pending_root_entry(
            root,
            root_lock,
            home,
            client,
            name,
            now_ns,
            target_state_name=state_name,
        )


def _load_pending_session_at(
    root: _SecureDirectory,
    home: Path,
    client: str,
    state_name: str,
) -> tuple[dict[str, Any] | None, str]:
    name = _pending_session_name(state_name)
    mode = _existing_kind(root, name)
    if mode is None:
        return None, "missing"
    if not stat.S_ISREG(mode):
        return None, "corrupt"
    try:
        fd = _open_secure_file_at(root, name, os.O_RDONLY, 0o600)
        try:
            info = os.fstat(fd)
            if os.name != "nt" and stat.S_IMODE(info.st_mode) != 0o600:
                return None, "corrupt"
            raw = os.read(fd, 4097)
        finally:
            os.close(fd)
        if len(raw) > 4096:
            return None, "corrupt"
        value = json.loads(raw)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None, "corrupt"
    if not _valid_session_manifest(value, home, client, state_name):
        return None, "corrupt"
    return value, "valid"


def _ensure_pending_session_at(
    root: _SecureDirectory,
    root_lock: _AdvisoryLock,
    home: Path,
    client: str,
    session_id: str,
    created_at_ns: int,
) -> dict[str, Any]:
    state_name = session_state_dir(home, client, session_id).name
    _cleanup_pending_temporaries_for_state(root, root_lock, home, client, state_name)
    existing, status_value = _load_pending_session_at(root, home, client, state_name)
    if status_value == "valid" and existing is not None:
        return existing
    if status_value != "missing":
        raise OSError("invalid pending continuation session manifest")
    value = _session_manifest(home, client, session_id, created_at_ns)
    raw = _canonical_bytes(value)
    temporary = f".pending-{state_name}.tmp-{os.getpid()}-{secrets.token_hex(8)}"
    _register_prune_catalog_entry(root, root_lock, temporary)
    fd = _open_secure_file_at(
        root,
        temporary,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL,
        0o600,
    )
    try:
        _write_all(fd, raw)
        os.fsync(fd)
    finally:
        os.close(fd)
    try:
        _register_prune_catalog_entry(
            root,
            root_lock,
            _pending_session_name(state_name),
        )
        _replace_at(root, temporary, _pending_session_name(state_name))
        _unregister_prune_catalog_entry(root, root_lock, temporary)
    except BaseException:
        try:
            _unlink_at(root, temporary)
            if _existing_kind(root, temporary) is None:
                _unregister_prune_catalog_entry(root, root_lock, temporary)
        except OSError:
            pass
        raise
    return value


def _ensure_session_manifest(
    state: _SecureDirectory,
    home: Path,
    client: str,
    session_id: str,
    created_at_ns: int,
    *,
    descriptor: int | None = None,
) -> None:
    """Write the session manifest into `.lock`, through a held descriptor if given.

    Same reason as `load_session_manifest_at`: Windows byte-range locks are
    mandatory, so a caller already holding this file's advisory lock cannot
    reach the bytes through a second descriptor. The pruner does exactly that
    when it adopts a pending record for a session killed before its manifest
    was written, which is why that case could never be repaired -- and so never
    pruned -- on Windows.
    """
    fd = descriptor if descriptor is not None else _open_secure_file_at(
        state, ".lock", os.O_RDWR | os.O_CREAT, 0o600
    )
    try:
        if descriptor is not None:
            os.lseek(fd, 0, os.SEEK_SET)
        raw = os.read(fd, 4097)
        if raw not in {b"", b"\0"}:
            return
        payload = b"\0" + _canonical_bytes(
            _session_manifest(home, client, session_id, created_at_ns)
        )
        os.lseek(fd, 0, os.SEEK_SET)
        _write_all(fd, payload)
        os.ftruncate(fd, len(payload))
        os.fsync(fd)
    finally:
        if descriptor is None:
            os.close(fd)


def load_session_manifest_at(
    state: _SecureDirectory,
    home: Path,
    client: str,
    state_name: str,
    *,
    descriptor: int | None = None,
) -> tuple[dict[str, Any] | None, str]:
    """Read the session manifest, optionally through a descriptor already held.

    The manifest lives inside `.lock`, and a caller holding that file's
    advisory lock must pass its descriptor. POSIX locks are advisory, so a
    second descriptor could read the bytes regardless; Windows byte-range
    locks are mandatory, and the read through a second descriptor is refused.
    That refusal surfaced as `corrupt` -- indistinguishable from a genuinely
    damaged manifest -- and it made every expired session whose first write was
    interrupted permanently unprunable on Windows, because the pruner reads the
    manifest while holding exactly that lock. Reading through the descriptor
    that owns the lock is allowed on both platforms.
    """
    try:
        fd = descriptor if descriptor is not None else _open_secure_file_at(
            state, ".lock", os.O_RDONLY, 0o600
        )
        try:
            info = os.fstat(fd)
            if os.name != "nt" and stat.S_IMODE(info.st_mode) != 0o600:
                return None, "corrupt"
            if descriptor is not None:
                os.lseek(fd, 0, os.SEEK_SET)
            raw = os.read(fd, 4097)
        finally:
            if descriptor is None:
                os.close(fd)
        if not raw.startswith(b"\0") or len(raw) > 4096:
            return None, "missing"
        value = json.loads(raw[1:])
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None, "corrupt"
    if not _valid_session_manifest(value, home, client, state_name):
        return None, "corrupt"
    return value, "valid"


@contextlib.contextmanager
def _session_lock(
    home: Path,
    client: str,
    session_id: str,
    *,
    create: bool,
    created_at_ns: int | None = None,
) -> Any:
    root = client_state_root(home, client)
    state_name = session_state_dir(home, client, session_id).name
    with _open_secure_directory(root, create=create) as root_handle:
        _require_private_state_directory(root_handle)
        with _advisory_lock_at(root_handle, ".root.lock") as root_lock:
            state_existed = _existing_kind(root_handle, state_name) is not None
            pending: dict[str, Any] | None = None
            if create:
                if state_existed:
                    pending, _pending_status = _load_pending_session_at(
                        root_handle, home, client, state_name
                    )
                else:
                    pending = _ensure_pending_session_at(
                        root_handle,
                        root_lock,
                        home,
                        client,
                        session_id,
                        time.time_ns() if created_at_ns is None else int(created_at_ns),
                    )
            if create and not state_existed:
                _register_prune_catalog_entry(root_handle, root_lock, state_name)
            state_context = _open_secure_child_directory(
                root_handle,
                state_name,
                create=create,
            )
            state_handle = state_context.__enter__()
            try:
                _require_private_state_directory(state_handle)
                _manifest, manifest_status = load_session_manifest_at(
                    state_handle, home, client, state_name
                )
                if (
                    state_existed
                    and manifest_status == "valid"
                    and not _prune_catalog_contains(root_handle, state_name)
                ):
                    _register_prune_catalog_entry(root_handle, root_lock, state_name)
                if pending is not None and not _prune_catalog_contains(
                    root_handle,
                    _pending_session_name(state_name),
                ):
                    _register_prune_catalog_entry(
                        root_handle,
                        root_lock,
                        _pending_session_name(state_name),
                    )
                if create and manifest_status != "valid" and pending is not None:
                    _ensure_session_manifest(
                        state_handle,
                        home,
                        client,
                        session_id,
                        int(pending["created_at_ns"]),
                    )
                    _manifest, manifest_status = load_session_manifest_at(
                        state_handle, home, client, state_name
                    )
                    if manifest_status != "valid":
                        raise OSError("continuation session manifest was not published")
                    try:
                        _unlink_at(root_handle, _pending_session_name(state_name))
                        if _existing_kind(root_handle, _pending_session_name(state_name)) is None:
                            _unregister_prune_catalog_entry(
                                root_handle,
                                root_lock,
                                _pending_session_name(state_name),
                            )
                    except OSError:
                        pass
                elif (
                    create
                    and manifest_status == "valid"
                    and pending is not None
                    and _manifest == pending
                    and _same_directory_entry(root_handle, state_name, state_handle)
                ):
                    try:
                        _unlink_at(root_handle, _pending_session_name(state_name))
                        if _existing_kind(root_handle, _pending_session_name(state_name)) is None:
                            _unregister_prune_catalog_entry(
                                root_handle,
                                root_lock,
                                _pending_session_name(state_name),
                            )
                    except OSError:
                        pass
                session = _advisory_lock_at(state_handle, ".lock")
                session.__enter__()
            except BaseException:
                state_context.__exit__(*sys.exc_info())
                raise
        try:
            yield state_handle
        finally:
            session.__exit__(None, None, None)
            state_context.__exit__(None, None, None)


def _recomputed(checkpoint: Mapping[str, Any]) -> dict[str, Any] | None:
    structural = checkpoint.get("structural")
    observed = checkpoint.get("observed_at_ns")
    if not isinstance(structural, dict) or not isinstance(observed, int):
        return None
    try:
        return finalize_checkpoint(structural, observed_at_ns=observed)
    except (KeyError, TypeError, ValueError):
        return None


def _bounded_safe_text(value: object, limit: int = MAX_IDENTIFIER_BYTES) -> bool:
    return (
        isinstance(value, str) and not _unsafe_text(value) and len(value.encode("utf-8")) <= limit
    )


def _safe_relative_path(value: object) -> bool:
    if not _bounded_safe_text(value, MAX_PATH_BYTES) or not isinstance(value, str):
        return False
    if value.startswith(("/", "\\")) or "\\" in value:
        return False
    parts = value.split("/")
    return bool(parts) and all(part not in {"", ".", ".."} for part in parts)


def _safe_basename(value: object) -> bool:
    return (
        _bounded_safe_text(value, MAX_PATH_BYTES)
        and isinstance(value, str)
        and value not in {"", ".", ".."}
        and "/" not in value
        and "\\" not in value
    )


def _valid_path_binding(value: object) -> bool:
    if not isinstance(value, dict) or set(value) != {"kind", "value"}:
        return False
    if value["kind"] == "sha256":
        return isinstance(value["value"], str) and bool(_HEX_64.fullmatch(value["value"]))
    return value["kind"] == "relative" and _safe_relative_path(value["value"])


def _valid_workspace(value: object) -> bool:
    if not isinstance(value, dict) or not isinstance(value.get("available"), bool):
        return False
    if not value["available"]:
        if not set(value).issubset({"available", "cwd_name", "cwd_sha256"}):
            return False
        if "cwd_name" in value and not _safe_basename(value["cwd_name"]):
            return False
        return "cwd_sha256" not in value or (
            isinstance(value["cwd_sha256"], str) and bool(_HEX_64.fullmatch(value["cwd_sha256"]))
        )
    if set(value) != {
        "available",
        "root",
        "root_sha256",
        "branch",
        "detached",
        "head",
        "dirty_paths",
    }:
        return False
    branch = value["branch"]
    head = value["head"]
    dirty = value["dirty_paths"]
    return (
        _safe_basename(value["root"])
        and isinstance(value["root_sha256"], str)
        and bool(_HEX_64.fullmatch(value["root_sha256"]))
        and (branch is None or _bounded_safe_text(branch, MAX_PATH_BYTES))
        and (value["detached"] is None or isinstance(value["detached"], bool))
        and (
            head is None
            or isinstance(head, str)
            and (bool(_HEX_40.fullmatch(head)) or bool(_HEX_64.fullmatch(head)))
        )
        and isinstance(dirty, list)
        and len(dirty) <= MAX_DIRTY_PATHS
        and all(_safe_relative_path(path) for path in dirty)
        and dirty == sorted(set(dirty))
    )


def _valid_transcript(value: object) -> bool:
    if not isinstance(value, dict) or not isinstance(value.get("available"), bool):
        return False
    if not value["available"]:
        return set(value).issubset({"available", "path"}) and (
            "path" not in value or _valid_path_binding(value["path"])
        )
    if set(value) != {
        "available",
        "path",
        "observed_size",
        "observed_mtime_ns",
        "slice_offset",
        "slice_length",
        "slice_sha256",
    }:
        return False
    numeric = (
        value["observed_size"],
        value["observed_mtime_ns"],
        value["slice_offset"],
        value["slice_length"],
    )
    if any(type(item) is not int or item < 0 for item in numeric):
        return False
    return (
        _valid_path_binding(value["path"])
        and value["slice_length"] <= TRANSCRIPT_SLICE_BYTES
        and value["slice_offset"] + value["slice_length"] <= value["observed_size"]
        and isinstance(value["slice_sha256"], str)
        and bool(_HEX_64.fullmatch(value["slice_sha256"]))
    )


def _valid_artifact(value: object) -> bool:
    if not isinstance(value, dict) or set(value) != {
        "path",
        "size",
        "mtime_ns",
        "sha256",
        "completed_count",
        "incomplete_count",
        "incomplete_lines",
    }:
        return False
    path = value["path"]
    numbers = (
        value["size"],
        value["mtime_ns"],
        value["completed_count"],
        value["incomplete_count"],
    )
    lines = value["incomplete_lines"]
    return (
        isinstance(path, str)
        and _safe_relative_path(path)
        and _allowed_artifact_relative(path)
        and all(type(number) is int and number >= 0 for number in numbers)
        and isinstance(value["sha256"], str)
        and bool(_HEX_64.fullmatch(value["sha256"]))
        and isinstance(lines, list)
        and len(lines) <= MAX_INCOMPLETE_LINES
        and all(type(line) is int and line > 0 for line in lines)
        and lines == sorted(set(lines))
        and value["incomplete_count"] >= len(lines)
    )


def _valid_structural_contract(value: object) -> bool:
    if not isinstance(value, dict) or set(value) != {
        "schema_version",
        "client",
        "session_id",
        "turn_id",
        "event",
        "trigger",
        "source",
        "model",
        "state_root_binding",
        "workspace",
        "transcript",
        "artifacts",
        "degradation",
        "truncation",
    }:
        return False
    client = value["client"]
    event = value["event"]
    if (
        type(value["schema_version"]) is not int
        or value["schema_version"] != SCHEMA_VERSION
        or not isinstance(client, str)
        or client not in _CLIENT_EVENTS
    ):
        return False
    if not isinstance(event, str) or event not in _WRITE_EVENTS[client]:
        return False
    contract = _CLIENT_EVENTS[client][event]
    trigger = value["trigger"]
    source = value["source"]
    if (trigger is not None and not isinstance(trigger, str)) or (
        source is not None and not isinstance(source, str)
    ):
        return False
    if "trigger" in contract:
        if trigger not in contract["trigger"] or source is not None:
            return False
    elif "source" in contract:
        if source not in contract["source"] or trigger is not None:
            return False
    elif trigger is not None or source is not None:
        return False
    if not _bounded_safe_text(value["session_id"]):
        return False
    if value["turn_id"] is not None and not _bounded_safe_text(value["turn_id"]):
        return False
    if value["model"] is not None and not _bounded_safe_text(value["model"]):
        return False
    artifacts = value["artifacts"]
    degradation = value["degradation"]
    truncation = value["truncation"]
    return (
        isinstance(value["state_root_binding"], str)
        and bool(_HEX_64.fullmatch(value["state_root_binding"]))
        and _valid_workspace(value["workspace"])
        and _valid_transcript(value["transcript"])
        and isinstance(artifacts, list)
        and len(artifacts) <= MAX_ARTIFACTS
        and all(_valid_artifact(artifact) for artifact in artifacts)
        and isinstance(degradation, list)
        and all(isinstance(item, str) for item in degradation)
        and degradation == sorted(set(degradation))
        and all(item in _ALLOWED_DEGRADATION for item in degradation)
        and isinstance(truncation, dict)
        and set(truncation).issubset(_ALLOWED_TRUNCATION)
        and all(flag is True for flag in truncation.values())
    )


def _decode_checkpoint(raw: bytes) -> dict[str, Any] | None:
    try:
        if len(raw) > MAX_CHECKPOINT_BYTES:
            return None
        loaded = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if (
        not isinstance(loaded, dict)
        or set(loaded)
        != {
            "schema_version",
            "checkpoint_id",
            "structural_digest",
            "observed_at_ns",
            "event_order",
            "structural",
        }
        or type(loaded.get("schema_version")) is not int
        or loaded.get("schema_version") != SCHEMA_VERSION
        or not isinstance(loaded.get("checkpoint_id"), str)
        or _HEX_64.fullmatch(loaded["checkpoint_id"]) is None
        or not isinstance(loaded.get("structural_digest"), str)
        or _HEX_64.fullmatch(loaded["structural_digest"]) is None
        or type(loaded.get("observed_at_ns")) is not int
        or loaded["observed_at_ns"] < 0
        or not _valid_structural_contract(loaded.get("structural"))
    ):
        return None
    recomputed = _recomputed(loaded)
    if recomputed is None:
        return None
    for key in ("checkpoint_id", "structural_digest", "event_order"):
        if loaded.get(key) != recomputed.get(key):
            return None
    return loaded


def load_checkpoint_status_at(
    directory: _SecureDirectory,
    name: str,
) -> tuple[dict[str, Any] | None, str]:
    if _existing_kind(directory, name) is None:
        return None, "missing"
    try:
        fd = _open_secure_file_at(directory, name, os.O_RDONLY, 0o600)
        try:
            info = os.fstat(fd)
            if os.name != "nt" and stat.S_IMODE(info.st_mode) != 0o600:
                return None, "corrupt"
            raw = os.read(fd, MAX_CHECKPOINT_BYTES + 1)
        finally:
            os.close(fd)
    except OSError:
        return None, "corrupt"
    decoded = _decode_checkpoint(raw)
    return (decoded, "valid") if decoded is not None else (None, "corrupt")


def load_checkpoint_at(directory: _SecureDirectory, name: str) -> dict[str, Any] | None:
    return load_checkpoint_status_at(directory, name)[0]


def load_checkpoint(path: Path) -> dict[str, Any] | None:
    try:
        with _open_secure_directory(path.parent, create=False) as directory:
            return load_checkpoint_at(directory, path.name)
    except OSError:
        return None


def _write_all(fd: int, value: bytes) -> None:
    view = memoryview(value)
    while view:
        written = os.write(fd, view)
        if written <= 0:
            raise OSError("short state write")
        view = view[written:]


def _write_temp(state: _SecureDirectory, checkpoint: Mapping[str, Any]) -> str:
    temporary = f"current.json.tmp-{os.getpid()}-{secrets.token_hex(8)}"
    fd = _open_secure_file_at(
        state,
        temporary,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL,
        0o600,
    )
    try:
        _write_all(fd, encode_checkpoint(dict(checkpoint)))
        os.fsync(fd)
    except BaseException:
        os.close(fd)
        try:
            _unlink_at(state, temporary)
        except OSError:
            pass
        raise
    os.close(fd)
    return temporary


def _list_directory(directory: _SecureDirectory) -> list[str]:
    if os.name == "nt":
        return os.listdir(directory.path)
    return os.listdir(directory.fd)


def _list_directory_bounded(
    directory: _SecureDirectory,
    limit: int,
) -> tuple[list[str], bool]:
    target: object = directory.path if os.name == "nt" else directory.fd
    names: list[str] = []
    with os.scandir(target) as entries:
        for entry in entries:
            if len(names) >= limit:
                return sorted(names), True
            names.append(entry.name)
    return sorted(names), False


def _linux_directory_window(
    directory: _SecureDirectory,
    cursor: int,
    limit: int,
    deadline: float,
) -> tuple[list[str], int, bool, int]:
    """Read a bounded Linux getdents window with a restartable directory cookie."""
    import ctypes

    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_CLOEXEC", 0)
    scan_fd = os.open(".", flags, dir_fd=directory.fd)
    try:
        if cursor:
            os.lseek(scan_fd, cursor, os.SEEK_SET)
        libc = ctypes.CDLL(None, use_errno=True)
        getdents64 = libc.getdents64
        getdents64.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t]
        getdents64.restype = ctypes.c_ssize_t
        buffer = ctypes.create_string_buffer(4096)
        names: list[str] = []
        inspected = 0
        next_cursor = cursor
        while len(names) < limit and not _over_budget(deadline, inspected):
            count = int(getdents64(scan_fd, ctypes.addressof(buffer), len(buffer)))
            if count < 0:
                error = ctypes.get_errno()
                raise OSError(error, os.strerror(error))
            if count == 0:
                return names, 0, True, inspected
            offset = 0
            raw = buffer.raw
            while offset < count:
                if _over_budget(deadline, inspected):
                    return names, next_cursor, False, inspected
                record_length = int.from_bytes(raw[offset + 16 : offset + 18], "little")
                if record_length < 20 or offset + record_length > count:
                    raise OSError(errno.EIO, "invalid directory record")
                next_cursor = max(
                    0,
                    int.from_bytes(raw[offset + 8 : offset + 16], "little", signed=True),
                )
                name_raw = raw[offset + 19 : offset + record_length].split(b"\0", 1)[0]
                offset += record_length
                name = os.fsdecode(name_raw)
                if name in {".", ".."}:
                    continue
                inspected += 1
                names.append(name)
                if len(names) >= limit:
                    return names, next_cursor, False, inspected
        return names, next_cursor, False, inspected
    finally:
        os.close(scan_fd)


def _posix_directory_window(
    directory: _SecureDirectory,
    cursor: int,
    limit: int,
    deadline: float,
) -> tuple[list[str], int, bool, int]:
    """Read a bounded POSIX directory stream using seekdir/telldir cookies."""
    import ctypes

    if sys.platform == "darwin":

        class _Dirent(ctypes.Structure):
            _fields_ = [
                ("d_ino", ctypes.c_uint64),
                ("d_seekoff", ctypes.c_uint64),
                ("d_reclen", ctypes.c_uint16),
                ("d_namlen", ctypes.c_uint16),
                ("d_type", ctypes.c_uint8),
                ("d_name", ctypes.c_char * 1024),
            ]

    elif sys.platform.startswith("freebsd"):

        class _Dirent(ctypes.Structure):
            _fields_ = [
                ("d_fileno", ctypes.c_uint64),
                ("d_off", ctypes.c_int64),
                ("d_reclen", ctypes.c_uint16),
                ("d_type", ctypes.c_uint8),
                ("d_pad0", ctypes.c_uint8),
                ("d_namlen", ctypes.c_uint16),
                ("d_pad1", ctypes.c_uint16),
                ("d_name", ctypes.c_char * 256),
            ]

    else:

        class _Dirent(ctypes.Structure):
            _fields_ = [
                ("d_ino", ctypes.c_ulong),
                ("d_off", ctypes.c_long),
                ("d_reclen", ctypes.c_ushort),
                ("d_type", ctypes.c_ubyte),
                ("d_name", ctypes.c_char * 256),
            ]

    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_CLOEXEC", 0)
    scan_fd = os.open(".", flags, dir_fd=directory.fd)
    libc = ctypes.CDLL(None, use_errno=True)
    fdopendir = libc.fdopendir
    fdopendir.argtypes = [ctypes.c_int]
    fdopendir.restype = ctypes.c_void_p
    readdir = libc.readdir
    readdir.argtypes = [ctypes.c_void_p]
    readdir.restype = ctypes.POINTER(_Dirent)
    telldir = libc.telldir
    telldir.argtypes = [ctypes.c_void_p]
    telldir.restype = ctypes.c_long
    seekdir = libc.seekdir
    seekdir.argtypes = [ctypes.c_void_p, ctypes.c_long]
    seekdir.restype = None
    closedir = libc.closedir
    closedir.argtypes = [ctypes.c_void_p]
    closedir.restype = ctypes.c_int
    stream = fdopendir(scan_fd)
    if not stream:
        error = ctypes.get_errno()
        os.close(scan_fd)
        raise OSError(error, os.strerror(error))
    try:
        if cursor:
            signed_cursor = cursor - (1 << 64) if cursor >= (1 << 63) else cursor
            seekdir(stream, signed_cursor)
        names: list[str] = []
        inspected = 0
        next_cursor = cursor
        while inspected < limit and not _over_budget(deadline, inspected):
            ctypes.set_errno(0)
            entry = readdir(stream)
            if not entry:
                error = ctypes.get_errno()
                if error:
                    raise OSError(error, os.strerror(error))
                return names, 0, True, inspected
            cookie = int(telldir(stream))
            if cookie == -1:
                error = ctypes.get_errno()
                raise OSError(error or errno.EIO, os.strerror(error or errno.EIO))
            next_cursor = cookie % (1 << 64)
            name = os.fsdecode(bytes(entry.contents.d_name).split(b"\0", 1)[0])
            if name in {".", ".."}:
                continue
            inspected += 1
            names.append(name)
        return names, next_cursor, False, inspected
    finally:
        closedir(stream)


def _resumes_a_directory_stream_from_a_saved_cookie() -> bool:
    """Whether a `telldir` cookie outlives the stream that produced it.

    Every window here opens a fresh directory stream and resumes it from the
    cookie the previous window returned, so the cookie has to mean the same
    thing to a stream that has never seen it. glibc satisfies that: its
    `telldir` hands back the filesystem's own `d_off`. The 4.4BSD lineage,
    Darwin included, instead returns an index into a location table owned by
    the *DIR that produced it*; replayed into a new stream it resolves
    against a table that no longer holds it and the scan lands at an
    arbitrary offset. Measured on macOS as entries scattered through a
    257-entry directory that no window ever returned. Windows has no cookie
    of any kind. Both resume from the durable prune catalog instead.
    """
    return sys.platform.startswith("linux") and os.name != "nt"


def _directory_window(
    directory: _SecureDirectory,
    *,
    cursor: int,
    limit: int,
    deadline: float,
    force_portable: bool = False,
) -> tuple[list[str], int, bool, int]:
    if sys.platform.startswith("linux") and os.name != "nt" and not force_portable:
        return _linux_directory_window(directory, cursor, limit, deadline)
    if os.name != "nt":
        if cursor and not _resumes_a_directory_stream_from_a_saved_cookie():
            raise OSError(
                "this platform resumes a root scan from the durable prune catalog"
            )
        return _posix_directory_window(directory, cursor, limit, deadline)
    # Windows exposes no resumable directory cursor: `os.scandir` has no
    # `telldir`/`seekdir` equivalent, and re-scanning a prefix to reach the
    # cursor replays a growing prefix under a fixed budget -- the shape
    # `_prune_catalog_window` exists to avoid. Root pruning routes there on
    # `nt`; every other caller enumerates from the start, so the cursor this
    # branch reports back is always 0.
    if cursor:
        raise OSError("this platform resumes a root scan from the durable prune catalog")
    names: list[str] = []
    inspected = 0
    with os.scandir(directory.path) as entries:
        for entry in entries:
            if _over_budget(deadline, inspected):
                return names, 0, False, inspected
            inspected += 1
            names.append(entry.name)
            if len(names) >= limit:
                return names, 0, False, inspected
    return names, 0, True, inspected


def _cleanup_temporaries(
    state: _SecureDirectory,
    *,
    deadline: float | None = None,
) -> None:
    scan_deadline = time.monotonic() + MAX_PRUNE_LOCK_SECONDS if deadline is None else deadline
    try:
        names, _cursor, _exhausted, _inspected = _directory_window(
            state,
            cursor=0,
            limit=MAX_STATE_ENUM_ENTRIES,
            deadline=scan_deadline,
        )
    except OSError:
        return
    for name in names:
        if time.monotonic() >= scan_deadline:
            return
        if not name.startswith("current.json.tmp-"):
            continue
        try:
            _unlink_at(state, name)
        except OSError:
            continue


_STATE_TEMPORARY = re.compile(r"^current\.json\.tmp-[0-9]+-[0-9a-f]{16}$")


def _recognized_state_name(name: str) -> bool:
    return name in {".lock", "current.json", "previous.json"} or bool(
        _STATE_TEMPORARY.fullmatch(name)
    )


def _recognized_state_directory(
    state: _SecureDirectory,
    *,
    deadline: float | None = None,
) -> bool:
    scan_deadline = time.monotonic() + MAX_PRUNE_LOCK_SECONDS if deadline is None else deadline
    try:
        names, _cursor, exhausted, _inspected = _directory_window(
            state,
            cursor=0,
            limit=MAX_STATE_ENUM_ENTRIES,
            deadline=scan_deadline,
        )
    except OSError:
        return False
    if not exhausted:
        return False
    for name in names:
        if time.monotonic() >= scan_deadline:
            return False
        if not _recognized_state_name(name):
            return False
        mode = _existing_kind(state, name)
        if mode is None or not stat.S_ISREG(mode):
            return False
    return True


def _prune_candidate_authorized(
    candidate: Mapping[str, Any],
    home: Path,
    client: str,
    enumerated_name: str,
) -> bool:
    structural = candidate.get("structural")
    if not isinstance(structural, Mapping):
        return False
    session_id = structural.get("session_id")
    return (
        isinstance(session_id, str)
        and bool(session_id)
        and structural.get("client") == client
        and structural.get("state_root_binding") == _state_root_binding(home, client)
        and session_state_dir(home, client, session_id).name == enumerated_name
    )


def _replace_current_with_candidate(
    state: _SecureDirectory,
    candidate: Mapping[str, Any],
) -> None:
    temporary = _write_temp(state, candidate)
    try:
        _replace_at(state, temporary, "current.json")
    except BaseException:
        try:
            _unlink_at(state, temporary)
        except OSError:
            pass
        raise


def write_checkpoint(
    event: Mapping[str, Any],
    home: Path,
    *,
    observed_at_ns: int | None = None,
) -> dict[str, Any]:
    event = _bound_event_identifiers(event)
    observed = time.time_ns() if observed_at_ns is None else int(observed_at_ns)
    candidate = build_checkpoint(event, home, observed_at_ns=observed)
    with _session_lock(
        home,
        str(event["client"]),
        str(event["session_id"]),
        create=True,
        created_at_ns=observed,
    ) as state:
        _cleanup_temporaries(state)
        current, current_status = load_checkpoint_status_at(state, "current.json")
        if current is not None and current["checkpoint_id"] == candidate["checkpoint_id"]:
            if tuple(candidate["event_order"]) > tuple(current["event_order"]):
                _replace_current_with_candidate(state, candidate)
            previous = load_checkpoint_at(state, "previous.json")
            if previous is not None and previous["checkpoint_id"] == candidate["checkpoint_id"]:
                _unlink_at(state, "previous.json")
            return {"status": "idempotent", "checkpoint_id": candidate["checkpoint_id"]}
        if current is not None and tuple(current["event_order"]) > tuple(candidate["event_order"]):
            return {"status": "stale", "checkpoint_id": candidate["checkpoint_id"]}
        if current_status in {"missing", "corrupt"}:
            previous, previous_status = load_checkpoint_status_at(state, "previous.json")
            if previous_status == "valid" and previous is not None:
                if previous["checkpoint_id"] == candidate["checkpoint_id"]:
                    if tuple(candidate["event_order"]) > tuple(previous["event_order"]):
                        _replace_current_with_candidate(state, candidate)
                        _unlink_at(state, "previous.json")
                    else:
                        _replace_at(state, "previous.json", "current.json")
                    return {
                        "status": "idempotent",
                        "checkpoint_id": candidate["checkpoint_id"],
                    }
                if tuple(previous["event_order"]) > tuple(candidate["event_order"]):
                    _replace_at(state, "previous.json", "current.json")
                    return {"status": "stale", "checkpoint_id": candidate["checkpoint_id"]}
            elif previous_status == "corrupt":
                _unlink_at(state, "previous.json")
        temporary = _write_temp(state, candidate)
        try:
            if current is not None:
                _replace_at(state, "current.json", "previous.json")
            _replace_at(state, temporary, "current.json")
        except BaseException:
            try:
                _unlink_at(state, temporary)
            except OSError:
                pass
            raise
        return {"status": "written", "checkpoint_id": candidate["checkpoint_id"]}


def _binding_matches(candidate: Mapping[str, Any], event: Mapping[str, Any], home: Path) -> bool:
    saved = candidate.get("structural", {}).get("transcript", {})
    if not saved.get("available"):
        return True
    path_value = event.get("transcript_path")
    if not path_value:
        return True
    path = Path(str(path_value)).expanduser()
    if _path_binding(path, home) != saved.get("path"):
        return False
    try:
        fd = _safe_regular_fd(path)
        try:
            info = os.fstat(fd)
            if info.st_size < int(saved["observed_size"]):
                return False
            os.lseek(fd, int(saved["slice_offset"]), os.SEEK_SET)
            raw = os.read(fd, int(saved["slice_length"]))
        finally:
            os.close(fd)
    except (OSError, KeyError, TypeError, ValueError):
        return False
    return len(raw) == int(saved["slice_length"]) and _sha256_bytes(raw) == saved.get(
        "slice_sha256"
    )


def _candidate_matches(
    candidate: Mapping[str, Any],
    event: Mapping[str, Any],
    home: Path,
    now_ns: int,
) -> bool:
    structural = candidate.get("structural", {})
    observed = candidate.get("observed_at_ns")
    if not isinstance(observed, int) or now_ns - observed > RETENTION_NS:
        return False
    if structural.get("client") != event.get("client"):
        return False
    if structural.get("session_id") != event.get("session_id"):
        return False
    if structural.get("state_root_binding") != _state_root_binding(home, str(event["client"])):
        return False
    return _binding_matches(candidate, event, home)


def select_checkpoint(
    event: Mapping[str, Any],
    home: Path,
    *,
    now_ns: int | None = None,
) -> tuple[dict[str, Any], str] | None:
    event = _bound_event_identifiers(event)
    now = time.time_ns() if now_ns is None else int(now_ns)
    try:
        with _session_lock(
            home,
            str(event["client"]),
            str(event["session_id"]),
            create=False,
        ) as state:
            current, current_status = load_checkpoint_status_at(state, "current.json")
            previous, previous_status = load_checkpoint_status_at(state, "previous.json")
            if current_status == "valid":
                if (
                    previous_status == "valid"
                    and current is not None
                    and previous is not None
                    and not _generation_pair_ordered(current, previous)
                ):
                    return None
                if current is not None and _candidate_matches(current, event, home, now):
                    return current, "current"
                return None
            if (
                current_status in {"missing", "corrupt"}
                and previous_status == "valid"
                and previous is not None
                and _candidate_matches(previous, event, home, now)
            ):
                return previous, "rollback"
    except (OSError, TimeoutError):
        return None
    return None


def _generation_pair_ordered(current: Mapping[str, Any], previous: Mapping[str, Any]) -> bool:
    return current["checkpoint_id"] != previous["checkpoint_id"] and tuple(
        current["event_order"]
    ) > tuple(previous["event_order"])


def _rename_directory_at(root: _SecureDirectory, source: str, destination: str) -> None:
    source_mode = _existing_kind(root, source)
    if source_mode is None or not stat.S_ISDIR(source_mode):
        raise OSError("prune source is not a directory")
    if _existing_kind(root, destination) is not None:
        raise FileExistsError(destination)
    if os.name == "nt":
        _windows_rename_at(
            root,
            source,
            destination,
            source_is_directory=True,
            replace=False,
        )
    else:
        os.replace(source, destination, src_dir_fd=root.fd, dst_dir_fd=root.fd)


def _delete_tombstone_at(
    root: _SecureDirectory,
    name: str,
    expected_identity: tuple[object, ...] | None = None,
    *,
    deadline: float | None = None,
) -> bool:
    if not name.startswith(".tombstone-"):
        return False
    try:
        context = _open_secure_child_directory(
            root,
            name,
            create=False,
            delete_access=os.name == "nt",
        )
        tombstone = context.__enter__()
    except OSError:
        return False
    try:
        if expected_identity is not None and _directory_identity(tombstone) != expected_identity:
            return False
        scan_deadline = time.monotonic() + MAX_PRUNE_LOCK_SECONDS if deadline is None else deadline
        children, _cursor, exhausted, _inspected = _directory_window(
            tombstone,
            cursor=0,
            limit=MAX_STATE_ENUM_ENTRIES,
            deadline=scan_deadline,
        )
        if not exhausted:
            return False
        if any(
            not _recognized_state_name(child)
            or not stat.S_ISREG(_existing_kind(tombstone, child) or 0)
            for child in children
        ):
            return False
        # A tombstone is an already-committed decision to delete. Abandoning
        # one half-unlinked leaves debris AND returns False, so the caller
        # cannot tell a starving prune from an idle one -- it sees the same
        # ordinary 0 either way. The deadline decides whether to START
        # another unit of work, never whether to finish the one in flight,
        # and `children` is bounded by MAX_STATE_ENUM_ENTRIES above.
        for child in children:
            _unlink_at(tombstone, child)
        if os.name == "nt":
            _windows_delete_directory_handle(tombstone.windows_handle)
            return True
        if not _same_directory_entry(root, name, tombstone):
            return False
        os.rmdir(name, dir_fd=root.fd)
        return True
    except OSError:
        return False
    finally:
        context.__exit__(None, None, None)


def _tombstone_expired_candidate(
    root_handle: _SecureDirectory,
    root_lock: _AdvisoryLock,
    home: Path,
    client: str,
    name: str,
    now: int,
    *,
    force_fallback: bool,
    deadline: float | None = None,
) -> tuple[str, tuple[object, ...]] | None:
    state_context = None
    state_open = False
    try:
        state_context = _open_secure_child_directory(root_handle, name, create=False)
        state_handle = state_context.__enter__()
        state_open = True
        _require_private_state_directory(state_handle)
        lock = _advisory_lock_at(state_handle, ".lock", timeout=0.0)
        lock.__enter__()
    except (OSError, TimeoutError):
        if state_open and state_context is not None:
            state_context.__exit__(*sys.exc_info())
        return None
    locked = True
    try:
        if not _recognized_state_directory(state_handle, deadline=deadline):
            return None
        current = load_checkpoint_at(state_handle, "current.json")
        previous = load_checkpoint_at(state_handle, "previous.json")
        current_authorized = current is not None and _prune_candidate_authorized(
            current, home, client, name
        )
        previous_authorized = previous is not None and _prune_candidate_authorized(
            previous, home, client, name
        )
        if current_authorized and isinstance(current.get("observed_at_ns"), int):
            current_expired = now - int(current["observed_at_ns"]) > RETENTION_NS
            if not current_expired:
                if (
                    previous_authorized
                    and isinstance(previous.get("observed_at_ns"), int)
                    and now - int(previous["observed_at_ns"]) > RETENTION_NS
                ):
                    _unlink_at(state_handle, "previous.json")
                return None
        elif previous_authorized and isinstance(previous.get("observed_at_ns"), int):
            if now - int(previous["observed_at_ns"]) <= RETENTION_NS:
                return None
        else:
            manifest, manifest_status = load_session_manifest_at(
                state_handle, home, client, name, descriptor=lock.fd
            )
            if manifest_status != "valid" or manifest is None:
                pending, pending_status = _load_pending_session_at(root_handle, home, client, name)
                if (
                    pending_status == "valid"
                    and pending is not None
                    and now - int(pending["created_at_ns"]) > RETENTION_NS
                ):
                    _ensure_session_manifest(
                        state_handle,
                        home,
                        client,
                        str(pending["session_id"]),
                        int(pending["created_at_ns"]),
                        descriptor=lock.fd,
                    )
                    manifest, manifest_status = load_session_manifest_at(
                        state_handle, home, client, name, descriptor=lock.fd
                    )
                    if manifest_status == "valid":
                        try:
                            _unlink_at(root_handle, _pending_session_name(name))
                            if _existing_kind(root_handle, _pending_session_name(name)) is None:
                                _unregister_prune_catalog_entry(
                                    root_handle,
                                    root_lock,
                                    _pending_session_name(name),
                                )
                        except OSError:
                            pass
            if (
                manifest_status != "valid"
                or manifest is None
                or now - int(manifest["created_at_ns"]) <= RETENTION_NS
            ):
                return None
        state_identity = _directory_identity(state_handle)
        if _directory_entry_identity(root_handle, name) != state_identity:
            return None
        tombstone = f".tombstone-{name}-{secrets.token_hex(8)}"
        _register_prune_catalog_entry(root_handle, root_lock, tombstone)
        if force_fallback:
            lock.__exit__(None, None, None)
            locked = False
            state_context.__exit__(None, None, None)
            state_open = False
        try:
            _rename_directory_at(root_handle, name, tombstone)
        except PermissionError:
            if locked:
                lock.__exit__(None, None, None)
                locked = False
            if state_open:
                state_context.__exit__(None, None, None)
                state_open = False
            _rename_directory_at(root_handle, name, tombstone)
        _unregister_prune_catalog_entry(root_handle, root_lock, name)
        if _directory_entry_identity(root_handle, tombstone) != state_identity:
            if _existing_kind(root_handle, name) is None:
                try:
                    _rename_directory_at(root_handle, tombstone, name)
                    _register_prune_catalog_entry(root_handle, root_lock, name)
                    _unregister_prune_catalog_entry(root_handle, root_lock, tombstone)
                except OSError:
                    pass
            return None
        return tombstone, state_identity
    finally:
        if locked:
            lock.__exit__(None, None, None)
        if state_open:
            state_context.__exit__(None, None, None)


def _prune_catalog_header() -> bytes:
    prefix = (
        _PRUNE_CATALOG_MAGIC
        + MAX_PRUNE_CATALOG_ENTRIES.to_bytes(4, "big")
        + _PRUNE_CATALOG_RECORD_BYTES.to_bytes(4, "big")
        + b"\0" * 8
    )
    return prefix + hashlib.sha256(prefix).digest()


def _prune_catalog_size() -> int:
    return _PRUNE_CATALOG_HEADER_BYTES + MAX_PRUNE_CATALOG_ENTRIES * _PRUNE_CATALOG_RECORD_BYTES


def _read_exact_at(fd: int, offset: int, size: int) -> bytes:
    os.lseek(fd, offset, os.SEEK_SET)
    chunks: list[bytes] = []
    remaining = size
    while remaining:
        chunk = os.read(fd, remaining)
        if not chunk:
            break
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _write_exact_at(fd: int, offset: int, value: bytes) -> None:
    os.lseek(fd, offset, os.SEEK_SET)
    _write_all(fd, value)


def _initialize_prune_catalog(root: _SecureDirectory) -> None:
    if _existing_kind(root, _PRUNE_CATALOG_TEMP) is not None:
        try:
            fd = _open_secure_file_at(root, _PRUNE_CATALOG_TEMP, os.O_RDWR, 0o600)
            try:
                info = os.fstat(fd)
                valid = (
                    stat.S_ISREG(info.st_mode)
                    and (os.name == "nt" or stat.S_IMODE(info.st_mode) == 0o600)
                    and info.st_size == _prune_catalog_size()
                    and _read_exact_at(fd, 0, _PRUNE_CATALOG_HEADER_BYTES)
                    == _prune_catalog_header()
                )
            finally:
                os.close(fd)
            if valid:
                _replace_at(root, _PRUNE_CATALOG_TEMP, _PRUNE_CATALOG_NAME)
                return
        except OSError:
            pass
        _unlink_at(root, _PRUNE_CATALOG_TEMP)
    fd = _open_secure_file_at(
        root,
        _PRUNE_CATALOG_TEMP,
        os.O_RDWR | os.O_CREAT | os.O_EXCL,
        0o600,
    )
    try:
        _write_all(fd, _prune_catalog_header())
        os.ftruncate(fd, _prune_catalog_size())
        os.fsync(fd)
    except BaseException:
        os.close(fd)
        try:
            _unlink_at(root, _PRUNE_CATALOG_TEMP)
        except OSError:
            pass
        raise
    os.close(fd)
    try:
        _replace_at(root, _PRUNE_CATALOG_TEMP, _PRUNE_CATALOG_NAME)
    except BaseException:
        try:
            _unlink_at(root, _PRUNE_CATALOG_TEMP)
        except OSError:
            pass
        raise


def _open_prune_catalog(root: _SecureDirectory, *, create: bool) -> int:
    if _existing_kind(root, _PRUNE_CATALOG_NAME) is None:
        if not create:
            raise FileNotFoundError(_PRUNE_CATALOG_NAME)
        _initialize_prune_catalog(root)
    fd = _open_secure_file_at(root, _PRUNE_CATALOG_NAME, os.O_RDWR, 0o600)
    try:
        info = os.fstat(fd)
        if (
            not stat.S_ISREG(info.st_mode)
            or (os.name != "nt" and stat.S_IMODE(info.st_mode) != 0o600)
            or info.st_size != _prune_catalog_size()
            or _read_exact_at(fd, 0, _PRUNE_CATALOG_HEADER_BYTES) != _prune_catalog_header()
        ):
            raise OSError("invalid prune catalog")
        return fd
    except BaseException:
        os.close(fd)
        raise


def _prune_catalog_record_offset(slot: int) -> int:
    return _PRUNE_CATALOG_HEADER_BYTES + slot * _PRUNE_CATALOG_RECORD_BYTES


def _prune_catalog_key(name: str) -> bytes:
    return hashlib.sha256(name.casefold().encode("utf-8")).digest()


def _encode_prune_catalog_record(name: str) -> bytes:
    _validate_child_name(name)
    encoded = name.encode("utf-8")
    if not encoded or len(encoded) > MAX_IDENTIFIER_BYTES:
        raise OSError("prune catalog name is outside the bounded schema")
    prefix = (
        b"\1"
        + len(encoded).to_bytes(2, "big")
        + encoded.ljust(MAX_IDENTIFIER_BYTES, b"\0")
        + _prune_catalog_key(name)
    )
    return prefix + hashlib.sha256(prefix).digest()


def _prune_catalog_tombstone() -> bytes:
    prefix = b"\2" + b"\0" * (2 + MAX_IDENTIFIER_BYTES + 32)
    return prefix + hashlib.sha256(prefix).digest()


def _decode_prune_catalog_record(raw: bytes) -> tuple[str, str | None]:
    if len(raw) != _PRUNE_CATALOG_RECORD_BYTES:
        raise OSError("invalid prune catalog record size")
    if raw == b"\0" * _PRUNE_CATALOG_RECORD_BYTES:
        return "empty", None
    prefix, checksum = raw[:-32], raw[-32:]
    if not secrets.compare_digest(hashlib.sha256(prefix).digest(), checksum):
        raise OSError("invalid prune catalog record checksum")
    if raw[0] == 2 and raw == _prune_catalog_tombstone():
        return "tombstone", None
    if raw[0] != 1:
        raise OSError("invalid prune catalog record status")
    length = int.from_bytes(raw[1:3], "big")
    encoded = raw[3 : 3 + MAX_IDENTIFIER_BYTES]
    if length < 1 or length > MAX_IDENTIFIER_BYTES or any(encoded[length:]):
        raise OSError("invalid prune catalog record name")
    try:
        name = encoded[:length].decode("utf-8")
        _validate_child_name(name)
    except (UnicodeDecodeError, OSError) as error:
        raise OSError("invalid prune catalog record name") from error
    key = raw[3 + MAX_IDENTIFIER_BYTES : 3 + MAX_IDENTIFIER_BYTES + 32]
    if not secrets.compare_digest(key, _prune_catalog_key(name)):
        raise OSError("invalid prune catalog record key")
    return "live", name


def _read_prune_catalog_slot(fd: int, slot: int) -> tuple[str, str | None]:
    return _decode_prune_catalog_record(
        _read_exact_at(
            fd,
            _prune_catalog_record_offset(slot),
            _PRUNE_CATALOG_RECORD_BYTES,
        )
    )


def _prune_catalog_probe(name: str) -> tuple[int, ...]:
    start = int.from_bytes(_prune_catalog_key(name)[:8], "big")
    return tuple(
        (start + offset) % MAX_PRUNE_CATALOG_ENTRIES for offset in range(MAX_PRUNE_CATALOG_ENTRIES)
    )


def _register_prune_catalog_entry(
    root: _SecureDirectory,
    root_lock: _AdvisoryLock,
    name: str,
) -> None:
    if root_lock.fd is None:
        raise OSError("prune catalog registration requires the root lock")
    record = _encode_prune_catalog_record(name)
    fd = _open_prune_catalog(root, create=True)
    try:
        reusable: int | None = None
        for slot in _prune_catalog_probe(name):
            status_value, existing = _read_prune_catalog_slot(fd, slot)
            if status_value == "live" and existing is not None:
                if existing == name:
                    return
                if existing.casefold() == name.casefold():
                    raise OSError("prune catalog contains a portable name alias")
                continue
            if status_value == "tombstone" and reusable is None:
                reusable = slot
                continue
            if status_value == "empty":
                target = slot if reusable is None else reusable
                _write_exact_at(fd, _prune_catalog_record_offset(target), record)
                os.fsync(fd)
                return
        if reusable is not None:
            _write_exact_at(fd, _prune_catalog_record_offset(reusable), record)
            os.fsync(fd)
            return
        raise OSError("prune catalog capacity is exhausted")
    finally:
        os.close(fd)


def _unregister_prune_catalog_entry(
    root: _SecureDirectory,
    root_lock: _AdvisoryLock,
    name: str,
) -> None:
    if root_lock.fd is None:
        raise OSError("prune catalog removal requires the root lock")
    try:
        fd = _open_prune_catalog(root, create=False)
    except FileNotFoundError:
        return
    try:
        for slot in _prune_catalog_probe(name):
            status_value, existing = _read_prune_catalog_slot(fd, slot)
            if status_value == "empty":
                return
            if status_value == "live" and existing == name:
                _write_exact_at(
                    fd,
                    _prune_catalog_record_offset(slot),
                    _prune_catalog_tombstone(),
                )
                os.fsync(fd)
                return
    finally:
        os.close(fd)


def _prune_catalog_contains(root: _SecureDirectory, name: str) -> bool:
    try:
        fd = _open_prune_catalog(root, create=False)
    except FileNotFoundError:
        return False
    try:
        for slot in _prune_catalog_probe(name):
            status_value, existing = _read_prune_catalog_slot(fd, slot)
            if status_value == "empty":
                return False
            if status_value == "live" and existing == name:
                return True
        return False
    finally:
        os.close(fd)


def _prune_catalog_window(
    root: _SecureDirectory,
    *,
    cursor: int,
    limit: int,
    deadline: float,
) -> tuple[list[str], int, bool, int]:
    try:
        fd = _open_prune_catalog(root, create=False)
    except FileNotFoundError:
        return [], 0, True, 0
    try:
        position = cursor if 0 <= cursor < MAX_PRUNE_CATALOG_ENTRIES else 0
        names: list[str] = []
        inspected = 0
        while inspected < limit and position < MAX_PRUNE_CATALOG_ENTRIES:
            if _over_budget(deadline, inspected):
                return names, position, False, inspected
            status_value, name = _read_prune_catalog_slot(fd, position)
            inspected += 1
            position += 1
            if status_value == "live" and name is not None:
                names.append(name)
        if position >= MAX_PRUNE_CATALOG_ENTRIES:
            return names, 0, True, inspected
        return names, position, False, inspected
    finally:
        os.close(fd)


def _read_prune_sequence(lock: _AdvisoryLock, *, offset: int = 1) -> int:
    if lock.fd is None:
        return 0
    os.lseek(lock.fd, offset, os.SEEK_SET)
    raw = os.read(lock.fd, 8)
    return int.from_bytes(raw, "big") if len(raw) == 8 else 0


def _write_prune_sequence(
    lock: _AdvisoryLock,
    value: int,
    *,
    offset: int = 1,
) -> None:
    if lock.fd is None:
        return
    os.lseek(lock.fd, offset, os.SEEK_SET)
    _write_all(lock.fd, (value % (1 << 64)).to_bytes(8, "big"))
    os.fsync(lock.fd)


_TOMBSTONE = re.compile(r"^\.tombstone-(.+)-[0-9a-f]{16}$")


def _authorize_recovery_tombstone(
    root: _SecureDirectory,
    home: Path,
    client: str,
    tombstone_name: str,
    now: int,
    *,
    deadline: float | None = None,
) -> tuple[str, tuple[object, ...]] | None:
    match = _TOMBSTONE.fullmatch(tombstone_name)
    if match is None:
        return None
    original_name = match.group(1)
    context = None
    state_open = False
    lock = None
    locked = False
    try:
        context = _open_secure_child_directory(root, tombstone_name, create=False)
        state = context.__enter__()
        state_open = True
        _require_private_state_directory(state)
        lock = _advisory_lock_at(state, ".lock", timeout=0.0)
        lock.__enter__()
        locked = True
    except (OSError, TimeoutError):
        if state_open and context is not None:
            context.__exit__(*sys.exc_info())
        return None
    try:
        if not _recognized_state_directory(state, deadline=deadline):
            return None
        candidates = (
            load_checkpoint_at(state, "current.json"),
            load_checkpoint_at(state, "previous.json"),
        )
        authorized = next(
            (
                candidate
                for candidate in candidates
                if candidate is not None
                and _prune_candidate_authorized(candidate, home, client, original_name)
                and isinstance(candidate.get("observed_at_ns"), int)
                and now - int(candidate["observed_at_ns"]) > RETENTION_NS
            ),
            None,
        )
        if authorized is None:
            manifest, status_value = load_session_manifest_at(
                state, home, client, original_name, descriptor=lock.fd
            )
            if (
                status_value != "valid"
                or manifest is None
                or now - int(manifest["created_at_ns"]) <= RETENTION_NS
            ):
                return None
        return tombstone_name, _directory_identity(state)
    finally:
        if locked and lock is not None:
            lock.__exit__(None, None, None)
        if state_open and context is not None:
            context.__exit__(None, None, None)


def _clean_expired_previous_for_current(
    root: _SecureDirectory,
    home: Path,
    client: str,
    state_name: str,
    now: int,
    *,
    deadline: float | None = None,
) -> None:
    context = None
    state_open = False
    lock = None
    locked = False
    try:
        context = _open_secure_child_directory(root, state_name, create=False)
        state = context.__enter__()
        state_open = True
        _require_private_state_directory(state)
        lock = _advisory_lock_at(state, ".lock", timeout=0.0)
        lock.__enter__()
        locked = True
    except (OSError, TimeoutError):
        if state_open and context is not None:
            context.__exit__(*sys.exc_info())
        return
    try:
        if not _recognized_state_directory(state, deadline=deadline):
            return
        current = load_checkpoint_at(state, "current.json")
        previous = load_checkpoint_at(state, "previous.json")
        if (
            current is None
            or previous is None
            or not _prune_candidate_authorized(current, home, client, state_name)
            or not _prune_candidate_authorized(previous, home, client, state_name)
            or type(current.get("observed_at_ns")) is not int
            or type(previous.get("observed_at_ns")) is not int
            or now - int(current["observed_at_ns"]) > RETENTION_NS
            or now - int(previous["observed_at_ns"]) <= RETENTION_NS
        ):
            return
        _unlink_at(state, "previous.json")
    finally:
        if locked and lock is not None:
            lock.__exit__(None, None, None)
        if state_open and context is not None:
            context.__exit__(None, None, None)


def prune_expired(
    home: Path,
    client: str,
    *,
    current_session: str,
    now_ns: int | None = None,
    force_fallback: bool = False,
    force_portable_catalog: bool = False,
) -> int:
    root = client_state_root(home, client)
    now = time.time_ns() if now_ns is None else int(now_ns)
    current_name = session_state_dir(home, client, current_session).name
    tombstones: list[tuple[str, tuple[object, ...]]] = []
    lock_deadline = time.monotonic() + MAX_PRUNE_LOCK_SECONDS
    try:
        root_context = _open_secure_directory(root, create=False)
        root_handle = root_context.__enter__()
        _require_private_state_directory(root_handle)
    except OSError:
        return 0
    try:
        try:
            remaining = max(0.0, lock_deadline - time.monotonic())
            with _advisory_lock_at(root_handle, ".root.lock", timeout=remaining) as root_lock:
                if time.monotonic() < lock_deadline:
                    _clean_expired_previous_for_current(
                        root_handle,
                        home,
                        client,
                        current_name,
                        now,
                        deadline=lock_deadline,
                    )
                scan_cursor = _read_prune_sequence(root_lock, offset=17)
                if (
                    force_portable_catalog
                    or not _resumes_a_directory_stream_from_a_saved_cookie()
                ):
                    scanned_names, next_cursor, _exhausted, _inspected = _prune_catalog_window(
                        root_handle,
                        cursor=scan_cursor,
                        limit=MAX_PRUNE_ENUM_ENTRIES,
                        deadline=lock_deadline,
                    )
                else:
                    scanned_names, next_cursor, _exhausted, _inspected = _directory_window(
                        root_handle,
                        cursor=scan_cursor,
                        limit=MAX_PRUNE_ENUM_ENTRIES,
                        deadline=lock_deadline,
                    )
                _write_prune_sequence(root_lock, next_cursor, offset=17)
                for scanned_name in tuple(scanned_names):
                    if _existing_kind(root_handle, scanned_name) is None:
                        _unregister_prune_catalog_entry(
                            root_handle,
                            root_lock,
                            scanned_name,
                        )
                entries = [
                    name
                    for name in scanned_names
                    if (
                        _existing_kind(root_handle, name) is not None
                        and name != current_name
                        and not name.startswith(".")
                    )
                ]
                recovery_names = [
                    name
                    for name in scanned_names
                    if _existing_kind(root_handle, name) is not None
                    and name.startswith(".tombstone-")
                ]
                pending_done = 0
                for scanned_name in scanned_names:
                    if _over_budget(lock_deadline, pending_done):
                        break
                    pending_done += 1
                    if scanned_name.startswith(".pending-"):
                        _cleanup_pending_root_entry(
                            root_handle,
                            root_lock,
                            home,
                            client,
                            scanned_name,
                            now,
                        )
                recovery_done = 0
                for recovery_name in recovery_names:
                    if _over_budget(lock_deadline, recovery_done):
                        break
                    recovery_done += 1
                    recovered = _authorize_recovery_tombstone(
                        root_handle,
                        home,
                        client,
                        recovery_name,
                        now,
                        deadline=lock_deadline,
                    )
                    if recovered is not None:
                        tombstones.append(recovered)
        except (OSError, TimeoutError):
            return 0
        candidates_done = 0
        for name in entries:
            if _over_budget(lock_deadline, candidates_done):
                break
            candidates_done += 1
            try:
                remaining = max(0.0, lock_deadline - time.monotonic())
                with _advisory_lock_at(root_handle, ".root.lock", timeout=remaining) as root_lock:
                    tombstone = _tombstone_expired_candidate(
                        root_handle,
                        root_lock,
                        home,
                        client,
                        name,
                        now,
                        force_fallback=force_fallback,
                        deadline=lock_deadline,
                    )
                    if tombstone is not None:
                        tombstones.append(tombstone)
            except (OSError, TimeoutError):
                continue
            if _over_budget(lock_deadline, candidates_done):
                break
            time.sleep(0.001)
        removed = 0
        deletions_done = 0
        for item, identity in tombstones:
            if _over_budget(lock_deadline, deletions_done):
                break
            deletions_done += 1
            deleted = _delete_tombstone_at(
                root_handle,
                item,
                identity,
                deadline=lock_deadline,
            )
            removed += int(deleted)
            if deleted and time.monotonic() < lock_deadline:
                try:
                    remaining = max(0.0, lock_deadline - time.monotonic())
                    with _advisory_lock_at(
                        root_handle,
                        ".root.lock",
                        timeout=remaining,
                    ) as root_lock:
                        _unregister_prune_catalog_entry(root_handle, root_lock, item)
                except (OSError, TimeoutError):
                    pass
        return removed
    finally:
        root_context.__exit__(None, None, None)


def _metadata_log(
    home: Path,
    client: str,
    event: str,
    status: str,
    duration_ms: int,
    *,
    checkpoint_id: str | None = None,
    error_class: str | None = None,
    create_root: bool = True,
) -> None:
    root = client_state_root(home, client)
    row: dict[str, object] = {
        "event": event,
        "status": status,
        "duration_ms": duration_ms,
    }
    if checkpoint_id:
        row["checkpoint_id"] = checkpoint_id
    if error_class:
        row["error_class"] = error_class
    if not _valid_metadata_record(row):
        raise ValueError("invalid continuation metadata record")
    with _open_secure_directory(root, create=create_root) as root_handle:
        _require_private_state_directory(root_handle)
        with _advisory_lock_at(
            root_handle, ".events.lock", timeout=METADATA_LOG_LOCK_SECONDS
        ):
            row_bytes = _canonical_bytes(row) + b"\n"
            if _append_metadata_if_room(root_handle, row_bytes):
                return
            encoded = _read_metadata_lines(root_handle)
            encoded.append(row_bytes)
            if sum(map(len, encoded)) > MAX_METADATA_LOG_BYTES:
                retained: list[bytes] = []
                retained_bytes = 0
                target = MAX_METADATA_LOG_BYTES // 2
                for item in reversed(encoded):
                    if retained and retained_bytes + len(item) > target:
                        break
                    retained.append(item)
                    retained_bytes += len(item)
                encoded = list(reversed(retained))
            payload = b"".join(encoded)
            temporary = f".events.log.tmp-{os.getpid()}-{secrets.token_hex(8)}"
            fd = _open_secure_file_at(
                root_handle,
                temporary,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                0o600,
            )
            try:
                _write_all(fd, payload)
                os.fsync(fd)
            finally:
                os.close(fd)
            try:
                _replace_at(root_handle, temporary, "events.log")
            except BaseException:
                try:
                    _unlink_at(root_handle, temporary)
                except OSError:
                    pass
                raise


def _append_metadata_if_room(root_handle: _SecureDirectory, row_bytes: bytes) -> bool:
    kind = _existing_kind(root_handle, "events.log")
    if kind is None:
        return False
    if not stat.S_ISREG(kind):
        raise OSError(errno.EINVAL, "unsafe continuation metadata log")
    fd = _open_secure_file_at(root_handle, "events.log", os.O_RDWR, 0o600)
    try:
        info = os.fstat(fd)
        if os.name != "nt" and stat.S_IMODE(info.st_mode) != 0o600:
            raise OSError(errno.EPERM, "unsafe continuation metadata log mode")
        if info.st_size <= 0 or info.st_size + len(row_bytes) > MAX_METADATA_LOG_BYTES:
            return False
        os.lseek(fd, -1, os.SEEK_END)
        if os.read(fd, 1) != b"\n":
            return False
        os.lseek(fd, 0, os.SEEK_END)
        _write_all(fd, row_bytes)
        return True
    finally:
        os.close(fd)


def _valid_metadata_record(value: object) -> bool:
    if not isinstance(value, dict):
        return False
    required = {"event", "status", "duration_ms"}
    if not required <= value.keys():
        return False
    if (
        not isinstance(value["event"], str)
        or value["event"] not in _METADATA_EVENTS
        or not isinstance(value["status"], str)
        or value["status"] not in _METADATA_STATUSES
    ):
        return False
    duration = value["duration_ms"]
    if type(duration) is not int or not 0 <= duration <= MAX_METADATA_DURATION_MS:
        return False
    status = value["status"]
    if status in _METADATA_STATUSES_WITH_CHECKPOINT:
        return (
            set(value) == required | {"checkpoint_id"}
            and isinstance(value["checkpoint_id"], str)
            and _HEX_64.fullmatch(value["checkpoint_id"]) is not None
        )
    if status == "empty":
        return set(value) == required
    return (
        status == "error"
        and set(value) == required | {"error_class"}
        and isinstance(value["error_class"], str)
        and _ERROR_CLASS.fullmatch(value["error_class"]) is not None
    )


def _read_metadata_lines(root_handle: _SecureDirectory) -> list[bytes]:
    """Validated log lines, as the bytes already on disk.

    Rotation used to parse every retained record and then re-encode it. That
    round trip measured 31 ms of a 78 ms critical section on a warm box -- half
    the time this lock is held, spent reproducing bytes the writer had already
    written in canonical form, while every other writer waits. Validation is
    unchanged; only the re-encode is gone. A line that parses and validates is
    now kept verbatim, so a record written by a different version survives
    rotation as itself instead of being silently rewritten.
    """
    kind = _existing_kind(root_handle, "events.log")
    if kind is None:
        return []
    if not stat.S_ISREG(kind):
        raise OSError(errno.EINVAL, "unsafe continuation metadata log")
    fd = _open_secure_file_at(root_handle, "events.log", os.O_RDONLY)
    try:
        info = os.fstat(fd)
        if os.name != "nt" and stat.S_IMODE(info.st_mode) != 0o600:
            raise OSError(errno.EPERM, "unsafe continuation metadata log mode")
        read_limit = MAX_METADATA_LOG_BYTES // 2
        offset = max(0, info.st_size - read_limit)
        os.lseek(fd, offset, os.SEEK_SET)
        raw = os.read(fd, read_limit)
    finally:
        os.close(fd)
    if offset:
        separator = raw.find(b"\n")
        raw = raw[separator + 1 :] if separator >= 0 else b""
    if raw and not raw.endswith(b"\n"):
        separator = raw.rfind(b"\n")
        raw = raw[: separator + 1] if separator >= 0 else b""
    lines: list[bytes] = []
    for line in raw.splitlines():
        try:
            record = json.loads(line)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if _valid_metadata_record(record):
            lines.append(line + b"\n")
    return lines


def _disabled(environ: Mapping[str, str]) -> bool:
    return environ.get("EXOMEM_CONTINUATION_DISABLE", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _emit_continuation_output(value: Mapping[str, Any] | None) -> dict[str, Any] | None:
    if value is None:
        return None
    if (
        type(value.get("contract_version")) is not int
        or value.get("contract_version") != OUTPUT_CONTRACT_VERSION
        or value.get("kind") != "continuation"
        or value.get("event") != "SessionStart"
        or not isinstance(value.get("additional_context"), str)
    ):
        return None
    return {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": value["additional_context"],
        }
    }


def _emit_claude_output(value: Mapping[str, Any] | None) -> dict[str, Any] | None:
    return _emit_continuation_output(value)


def _emit_codex_output(value: Mapping[str, Any] | None) -> dict[str, Any] | None:
    return _emit_continuation_output(value)


_OUTPUT_ADAPTERS = {
    "claude": _emit_claude_output,
    "codex": _emit_codex_output,
}


def _valid_normalized_event(
    event: Mapping[str, Any],
    expected_client: str,
) -> bool:
    if set(event) != {
        "contract_version",
        "client",
        "event",
        "session_id",
        "turn_id",
        "trigger",
        "source",
        "cwd",
        "transcript_path",
        "model",
        "normalization",
    }:
        return False
    client = event.get("client")
    event_name = event.get("event")
    if (
        type(event.get("contract_version")) is not int
        or event.get("contract_version") != EVENT_CONTRACT_VERSION
        or client != expected_client
        or client not in _CLIENT_EVENTS
        or not isinstance(event_name, str)
        or event_name not in _CLIENT_EVENTS[client]
        or not _bounded_safe_text(event.get("session_id"))
        or not event["session_id"]
    ):
        return False
    for key in ("turn_id", "model"):
        if event[key] is not None and not _bounded_safe_text(event[key]):
            return False
    for key in ("cwd", "transcript_path"):
        if event[key] is not None and not isinstance(event[key], str):
            return False
    contract = _CLIENT_EVENTS[client][event_name]
    trigger = event["trigger"]
    source = event["source"]
    if (trigger is not None and not isinstance(trigger, str)) or (
        source is not None and not isinstance(source, str)
    ):
        return False
    if "trigger" in contract:
        if trigger not in contract["trigger"] or source is not None:
            return False
    elif "source" in contract:
        if source not in contract["source"] or trigger is not None:
            return False
    elif trigger is not None or source is not None:
        return False
    normalization = event["normalization"]
    if not isinstance(normalization, Mapping) or set(normalization) != {
        "degradation",
        "truncation",
    }:
        return False
    degradation = normalization["degradation"]
    truncation = normalization["truncation"]
    return (
        isinstance(degradation, list)
        and all(isinstance(item, str) for item in degradation)
        and degradation == sorted(set(degradation))
        and set(degradation).issubset(_NORMALIZATION_DEGRADATION)
        and isinstance(truncation, Mapping)
        and set(truncation).issubset(_NORMALIZATION_TRUNCATION)
        and all(flag is True for flag in truncation.values())
    )


def _dispatch_core(
    event: Mapping[str, Any],
    home: Path,
    *,
    expected_client: str,
) -> dict[str, Any] | None:
    if not _valid_normalized_event(event, expected_client):
        return None
    client = str(event["client"])
    started = time.monotonic_ns()
    # Before anything else, and for every event: the retrieve hook's continuity
    # token describes a run of turns this event ends.
    _clear_activation_token(home, client, str(event["session_id"]))
    _rearm_nudges(home, str(event["session_id"]))
    if event["event"] in {"PreCompact", "SessionEnd"}:
        try:
            outcome = write_checkpoint(event, home)
            try:
                prune_expired(home, client, current_session=event["session_id"])
            except BaseException:  # noqa: BLE001 - hook must contain every failure
                pass
            try:
                _metadata_log(
                    home,
                    client,
                    event["event"],
                    str(outcome.get("status", "written")),
                    (time.monotonic_ns() - started) // 1_000_000,
                    checkpoint_id=outcome.get("checkpoint_id"),
                )
            except BaseException:  # noqa: BLE001 - diagnostics cannot block the hook
                pass
        except BaseException as error:  # noqa: BLE001 - hook soft-fail boundary
            try:
                _metadata_log(
                    home,
                    client,
                    event["event"],
                    "error",
                    (time.monotonic_ns() - started) // 1_000_000,
                    error_class=type(error).__name__,
                )
            except BaseException:  # noqa: BLE001 - diagnostics cannot block the hook
                pass
        return None
    try:
        selected = select_checkpoint(event, home)
        if selected is None:
            try:
                _metadata_log(
                    home,
                    client,
                    event["event"],
                    "empty",
                    (time.monotonic_ns() - started) // 1_000_000,
                    create_root=False,
                )
            except BaseException:  # noqa: BLE001 - diagnostics cannot block the hook
                pass
            return None
        candidate, status = selected
        context = render_continuation(candidate, status=status)
        try:
            _metadata_log(
                home,
                client,
                event["event"],
                status,
                (time.monotonic_ns() - started) // 1_000_000,
                checkpoint_id=candidate.get("checkpoint_id"),
            )
        except BaseException:  # noqa: BLE001 - diagnostics cannot block the hook
            pass
    except BaseException as error:  # noqa: BLE001 - hook soft-fail boundary
        try:
            _metadata_log(
                home,
                client,
                event["event"],
                "error",
                (time.monotonic_ns() - started) // 1_000_000,
                error_class=type(error).__name__,
                create_root=False,
            )
        except BaseException:  # noqa: BLE001 - diagnostics cannot block the hook
            pass
        return None
    return {
        "contract_version": OUTPUT_CONTRACT_VERSION,
        "kind": "continuation",
        "event": "SessionStart",
        "additional_context": context,
    }


def dispatch_event(
    client: str,
    payload: Mapping[str, object],
    *,
    environ: Mapping[str, str] | None = None,
) -> dict[str, Any] | None:
    env = os.environ if environ is None else environ
    event = normalize_event(client, payload)
    if event is None or _disabled(env):
        return None
    neutral = _dispatch_core(
        event,
        resolve_home(client, env),
        expected_client=client,
    )
    return _OUTPUT_ADAPTERS[client](neutral)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--client", choices=("claude", "codex"), required=True)
    home = parser.add_mutually_exclusive_group()
    home.add_argument("--hook-home")
    home.add_argument("--hook-home-env")
    try:
        args = parser.parse_args(argv)
        if args.hook_home_env is not None:
            args.hook_home = os.environ.get(args.hook_home_env)
            if not args.hook_home or not args.hook_home.strip():
                return 0  # Never use an inherited profile when the platform home is absent.
        raw = sys.stdin.buffer.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            return 0
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            return 0
        env = dict(os.environ)
        if args.hook_home is not None:
            env["EXOMEM_HOOK_HOME"] = args.hook_home
        output = dispatch_event(args.client, payload, environ=env)
        if output is not None:
            sys.stdout.write(json.dumps(output, ensure_ascii=False, separators=(",", ":")))
        return 0
    except BaseException:  # noqa: BLE001 - process must never block the client
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
