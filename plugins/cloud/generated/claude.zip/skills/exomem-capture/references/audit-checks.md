# Audit checks

Per-check detail for the **audit** (lint) operation — what each check flags, its
severity behaviour, and the proposed fix. SKILL.md § "Audit (lint) checks" lists
the check names; read this when running or acting on an audit. Audit is
read-mostly: the output is a proposal report you review; nothing is rewritten
without explicit confirmation per item or batch.

The audit call itself is always read-only. Its default `detail="actionable"`
orders current blockers first, malformed/unregistered relation work next, and
ordinary findings after that. Grandfathered relation-disposition findings are
grouped into one deterministic `legacy_backlog` carrying exact observed,
available, omitted, and upstream-truncation counts plus bounded samples. Use
`detail="full"` for raw finding enumeration. `legacy_sample_limit` accepts only
integers from 0 through 50 and changes actionable sampling, never the checks or
stored knowledge.

- **Orphans** — compiled pages with zero inbound links and zero outbound links beyond their `sources` block. Propose: link or archive.
- **Broken wikilinks** — `[[X]]` where `X` does not resolve. The audit skips wikilinks inside fenced code blocks and inline code spans. Bare names resolve against filename stems AND frontmatter `title:` (so date-prefixed sources with a title match are not flagged); a link carrying an explicit non-`.md` extension (`[[…/scan.pdf]]`) resolves if that file exists on disk, matching Obsidian's attachment links. Findings inside append-only trees (`Sources/`, `Evidence/`) — which can't be repaired in place — are surfaced at `info` severity, keeping them out of the actionable `warn` set. Propose: fix path or create stub entity.
- **Supersession integrity** (`supersession_integrity`) — two defects in the supersession pointers you authored, neither of them thresholded or inferred. A **dangling pointer**: a `supersedes:` or `superseded_by:` wikilink that does not resolve to a page, which breaks the protocol's one promise — that a reader who lands on the old conclusion is led to the current one — and leaves them unable to tell "never superseded" from "superseded, link rotted". A **multi-headed chain**: a connected supersession chain with more than one member that nothing supersedes, so the chain no longer has a single current answer and every reader of it silently picks one. Reported at `warn` severity as defects, anchored per page (a chain finding anchors on the chain's first member and lists the heads in `meta.heads`). Parked statuses are deliberately **not** excluded — a `superseded` page is exactly where a rotted forward pointer lives. One case is **not** detected: a page still marked `status: active` that something else already points at with `superseded_by:` — the pointer resolves, so nothing here flags the contradiction. Nothing is repaired, re-pointed, or removed. Propose: fix the target path, restore the missing page, drop a pointer that describes a supersession that never happened, or decide which head is current. Because nothing here is a threshold this system chose, the category is part of the **default** attention surface.
- **Stale frontmatter** — required fields missing for the page type. Includes: patterns with `project:` (singular) when `projects:` (plural) is the convention for cross-project patterns.
- **`index.md` / `log.md` drift** — files in folders that are not catalogued, catalogue entries pointing to missing files, or `log.md` entries without corresponding artifacts on disk (and vice versa).
- **Unprocessed sources** (`unprocessed_source`) — a `Sources/` file that no live compiled note cites. A page in `ingested_into:` clears this citation-linkage finding only when it is live (not a draft, not archived or superseded) and lists the Source in its own `sources:`; each page that does not is a `derivative` on the finding, with its reason (`pending` for a draft, `retired`, `claim_unresolved` or `missing`). Findings are **aged and triaged oldest-first**: each carries `meta` (`age_days`, `age_bucket` ∈ fresh <30d / aging <90d / stale, `captured`, the title, a bounded excerpt, the recorded grouping fields and the `derivatives`) and escalates to `warn` once stale. Work the backlog in batches: read about ten with `review_memory(mode="unprocessed-sources", limit=10)`, group them by topic, call **`propose_compilation(sources=[…])`** (or `review_memory(mode="compilation", sources=[…])`) for an optional one-note scaffold, then follow the [source compilation pass](writing.md#source-compilation-pass). An opening excerpt is not a full-source read; one citation clears this queue, not semantic coverage. Dismissing an item lowers the visible count only; the served `outstanding` count falls when a live note cites the Source.
- **Status / location mismatch** — pages with `status: archived` not living in an `_archive/` subfolder, and vice versa.
- **Unfinished experiments** (`unfinished_experiments`) — an experiment whose `started` date is present, whose elapsed time **exceeds** its declared `duration`, and which records no `outcome:`. The trigger is the missing outcome, not the status: `status: concluded` says the experiment stopped, `outcome:` says what it showed, so a concluded experiment with no outcome is still surfaced — that is the case the check most exists for. An **open-ended `duration`** (`ongoing`, or any value that is not a finite span) declares no window and so can never exceed one; it is never flagged. Archived, superseded, and draft experiments are out of rotation and excluded. A measurement-only queue at `info` severity, ordered **oldest-first** by elapsed age, with `meta` carrying `started`, `duration_days`, `elapsed_days`, and `overdue_days`. Nothing is auto-concluded, archived, or inferred. Propose: write up the result (`status: concluded` plus a categorical `outcome:`), extend `duration:` if it is genuinely still running, or archive it. On the **attention** surface this category is opt-in — pass it in `categories` — so it never displaces the default daily queue.
- **Unfinished production lifecycles** — production-logs with `status: recorded` or earlier whose `published` field has been null for >60 days. Propose: update status, fill outcomes, or move to dropped.
- **Stale hubs / snapshots** — a *separate* concern from `stale_review` (which deliberately **excludes** hubs/snapshots): research-notes that play the hub or snapshot role are **expected** to drift — a hub refreshes on a major capability ship, a snapshot is point-in-time by design — so they're not ordinary stale-review candidates. No automated check currently flags these on their own cadence; refresh a hub when a major ship warrants it and treat snapshots as historical.
- **Unregistered project key** — pages with a `project:` or `projects:` value not in `_Schema/project-keys.yaml`. Catches drift from Tier 2 `create_file` escape-hatch writes that bypass the auto-register flow. Propose: fix the value via `edit` (frontmatter-patch mode; its typo guard will surface the intended key) or hand-add the new key to the YAML.
- **Graph drift** (`graph_drift`) — derived `.graph.sqlite` state missing, stale, disabled, or schema-incompatible. Propose: run `reconcile` to rebuild or refresh the sidecar. When graph indexing is disabled, drift checks are a read-only no-op and report availability metadata instead of loading optional dependencies.
- **Embedding drift** — sidecar rows whose row mtime is older than the on-disk file mtime (likely an out-of-band editor edit, e.g. Obsidian, that bypassed exomem's writer hooks). Propose: run `reconcile` (incremental, stale rows only) or `audit_fix(rebuild_embeddings=true)` (full wipe + rebuild) to refresh.
- **Stale review** (`stale_review`) — active compiled *conclusions* (research-note / insight / pattern / failure / entity) that are simultaneously **old** (frontmatter `updated`/`created` beyond `EXOMEM_STALE_AGE_DAYS`, default 365), **rarely surfaced** by `find` (appearances in `logs/queries.jsonl` `top_k` ≤ `EXOMEM_STALE_MAX_ACCESS`, default 1), and **low inbound-link degree** (wikilink-graph in-degree ≤ `EXOMEM_STALE_MAX_INBOUND`, default 1). A measurement-only review queue at `info` severity: it **surfaces** candidates (with `meta`: `age_days`, `age_bucket`, `inbound_count`, `access_count`) for you to judge, and **never** decays, down-ranks, hides, or moves anything — `find` ordering is unchanged (surfacing a candidate ≠ a forgetting curve). All three signals derive from what the KB already records (frontmatter dates, the link graph, the query log) — no new sidecar. AND-gated as a filter, not a score (no confidence concept). The access signal is gated by `EXOMEM_DISABLE_RELEVANCE_CHECK`; when the log is unavailable that conjunct is **dropped** (absence is "unknown", never a fabricated zero-access), so the gate falls back to age AND low-inbound. Scope is governed by access tier (read-write) + a conclusion type, so it spans the whole writeable KB (not a fixed folder list) and auto-excludes readonly trees, append-only `Sources/`/`Evidence/`, superseded/archived, index files, and hubs/snapshots. Propose: confirm still true (keep), `replace` (supersede), or archive.
- **Prediction window** (`prediction_window`) — a semantic unit whose authored `check_by` date has arrived or passed with nothing recorded against it. A unit is surfaced when its `check_by` is on or before today, it carries no `verdict:`, and it carries no outbound relation of kind `supports`, `contradicts`, `resolves`, or `evidenced_by`. Any governed unit kind carrying a `check_by` counts, not only `## Prediction` — if you authored a due date, it is a due date. **Clear it** by recording a categorical `verdict:` on the unit (`confirmed`, `refuted`, `qualified`, `inconclusive`, `abandoned`), by attaching the evidence that settles it with one of those four relations, or by moving `check_by` out if the question is genuinely still open. The check never judges whether the prediction held — that is your `verdict:` to write. Resolution is deliberately **unit-local**: only a `verdict` or a relation on the unit itself clears it, so evidence recorded on another page does not, and the honest fix is to record the judgment on the prediction where it belongs. Pages with `status` `superseded`, `archived`, `draft`, `dropped`, or `planned` are out of rotation and excluded. A measurement-only queue at `info` severity, ordered **most-overdue-first**, with each due unit surfaced as its own review item (identified by the unit's fingerprint, so editing a prediction resurfaces it rather than reusing an earlier decision). Unlike **unfinished experiments**, this queue is part of the **default** attention surface — you see due predictions without asking for them, because an obligation nobody is shown is one nobody meets.
- **Question aging** (`question_aging`) — a governed question unit (a `## Open Question` block, or any unit whose resolved category is `question`) on an active page whose authored date is at least 30 days old, carrying no `verdict:` and no answering relation of kind `supports`, `contradicts`, `resolves`, or `evidenced_by` **on the unit itself**. The unit-local rule is the same one **prediction window** uses, and for the same reason: an answer recorded elsewhere cannot address a unit, so record it where the question is. Read this one carefully: unlike every other due-state check, the 30 days is a number this system chose and not one you declared, so a finding here is explicitly a **review candidate and never a defect** — an open question is a legitimate long-lived state and leaving it open is a valid answer. Measurement-only at `info` severity, ordered **oldest-first**, each unit surfaced as its own review item identified by the unit's fingerprint. Because its threshold is invented rather than authored, this category is **opt-in** on the attention surface — pass it in `categories` — so a tuning decision can never displace authored work on the daily queue. Propose: answer it with a categorical `verdict:` on the unit, attach what settles it with one of those four relations, or leave it open.
- **Note cohesion** (`note_cohesion`) — a compiled page that has reached a size step: 9 semantic units, then 14, 21, 32, and so on, each step the previous one times 1.5 rounded up. Hubs (`hub` or `snapshot` tag), Sources, `index.md` and `log.md` are never asked. Like question aging, the steps are a number this system chose, so a finding is a **question and never a defect**: the item states the counts and asks whether the page answers more than one independent question. Read the page and answer. A page that answers one question stays whole however long it is: dismiss the item with an `intentional:` reason that names that question, and it stays quiet until the next step. A page that answers several, each with its own material, is split only through the curation lane with the user's exact plan confirmation. Measurement-only at `info` severity, one item per page. **Opt-in** on the attention surface — pass it in `categories` — and also served as a backlog in due-state, after dated obligations.
- **Relation debt** (`relation_debt`) — active writable compiled pages with no
  outbound body wikilinks or canonical note/block relations. It excludes
  archived/superseded pages, indexes, append-only/read-only trees, hubs, and
  snapshots. This is an informational Inbox proposal, not a write failure:
  inspect `read_connections(operation={'kind': 'suggest-relations'})` or `suggest-links`,
  then add only defensible edges under `## Relations` (or block `relations:`
  metadata). Never turn semantic proximity into a durable edge automatically.

## Artifact role and transient state

`artifact_role_promotion` measures reusable procedures with separately bound
successful outcomes and synthesis across distinct visible sources in active
experiments. `transient_state_review` measures current pending wording alongside
a compatible observed result for the same authored episode and subject. Both
are deterministic English cue checks; ambiguous or unsupported wording stays
quiet. Read the exact evidence units before deciding on a governed extraction
or correction. Review and capture workflows give examples and authority rules.
Explicit results expose `meta.coverage` as complete, capped, or unknown per
family, including empty results. Compact due-state omissions do not prove
complete coverage; reconciliation heals missing or stale derived support.

## Held collection view corrections

`collection_view_corrections` lists each owner edit of a store collection view
that the substrate held instead of applying: a save from a stale editor buffer
(`VIEW_CONFLICT`), an edit the collection's rules refuse (`VIEW_INVALID`), a
deleted view (`VIEW_DELETED`), or a view stamped by another store
(`VIEW_FOREIGN`). Each finding names the read-only view under the collection's
`Held/` directory, with `meta.held_id` and `meta.code`. The category is part of
the default attention surface, and it lists only corrections you may read.
Read the held view and its diagnostics first. A `VIEW_CONFLICT` or
`VIEW_FOREIGN` correction holds bytes that the view no longer shows. Resume a
Records `VIEW_CONFLICT` through `change_records(operation={"kind": "update", "held": ...})`, or
discard either with a reason; a later edit of the view never resolves them. A
`VIEW_INVALID` edit kept in place or a `VIEW_DELETED` view is resolved when the
owner saves a valid edit of the view, or when you discard it. Discarding an
invalid view that is still in place renders the view from the store again.

## Duplicate content and source URLs

Both categories are opt-in: pass them in `categories` on `audit` or `attention`.
The default audit and the default attention surface skip them, and every finding
is advisory. The lexical index only proposes groups. The audit reads each member
again and re-hashes its original, so a stale index entry gives no finding.

- `duplicate_content` reports one finding per group of two or more live Sources
  or Evidence pages whose bytes are identical. It names each member (`ref`,
  `path`, lane, families or import mappings, capture date), the suggested
  canonical page, the bytes a fold would free, and in `meta.steps` the exact
  `fold-duplicate` step for each copy. The suggestion is the oldest filing by
  capture date, then path, unless a page the fold cannot rewrite (a Source,
  Evidence page or another owner's page) cites another member: that member is
  then the canonical page. `meta.canonical_because` says which rule applied.
- A finding offers no step when `meta.no_fold` gives a reason: the group spans
  lanes, the pages are raw-protected, two or more members are cited by pages
  the fold cannot rewrite, or the fold refuses a pair (a text Source beside a
  Source with an original, or an Evidence page outside its family folders).
  Raw-protected Evidence is never rewritten, because a release grant binds to
  each page's content hash. A step appears only when proposal accepts it.
- A caller who cannot read every page sees only the members it can read, gets
  no step (a fold needs whole-namespace authority), and learns nothing about
  which unreadable page cites a member: its answer equals that of a vault
  without those pages.
- `duplicate_source_url` reports one finding per group of Sources that share a
  canonical URL but hold different text. It names them and offers no fold: link
  the Sources or supersede one through the normal tools.

The report counts groups and copies by lane and states that each count was
re-hashed. Before it counts, the audit reconciles the index with the pages and
calls the index `complete` only after that succeeds. `stale_index_groups`
counts groups whose entries no longer match their pages. `unverifiable_groups`
counts groups of raw-protected pages that lack the binding which proves their
original, with the reason in `unverifiable_because`. An index that cannot answer
(a new or rebuilding index answers this way until its background rebuild
lands) reads as `unchecked` with coverage `unknown`, never as zero findings. Propose the steps of one finding as a single
curation plan, keep or change its canonical page, then preview and confirm the
exact plan ([vault-care](vault-care.md#curation)).

## Stored original fixity

`original_fixity` lists each stored original that the background check found
`missing` or `corrupt_no_copy` (`error`), or `restored` (`info`). Each finding
names the binding page, with `meta.original_path`, `meta.cause`,
`meta.expected_sha256` and `meta.route`, the candidate copies that may hold the
expected bytes. A `restored` original needs no action: its changed bytes are in
Trash. The item stays until the check verifies that original again, which takes
up to one verification cycle. For the other two, tell the owner, with the cause
and the route. Never record a new hash for changed bytes.

## Path variants

`path_variants` (opt-in: `categories=["path_variants"]`) lists sibling names
that one portable filesystem would hold as a single entry. Names equal after
Unicode NFC normalisation and casefolding are defects (`error`): the vault
cannot be exported or opened on Windows or default macOS. Names equal only after
NFKC folding and dropping separators are candidates (`info`) for a human call.
Nothing merges automatically; join the folders by hand with `manage_memory_file`
and keep the spelling that already holds most pages.
