# Substrate infrastructure collection

`substrate.infrastructure` version `0.1.0` supplies the `base` and `postgres`
roles for shared Linux hosts. The collection requires Ansible Core 2.21.2 or later.

Playbooks select `substrate.infrastructure.base` or
`substrate.infrastructure.postgres`. Role inputs remain in each role's
`defaults/main.yml`. The base role requires administrator public keys and a
NetBird administration route, or temporary administrator SSH CIDRs.
The PostgreSQL role requires database credentials, TLS inputs, and encrypted
backup storage credentials.

The roles retain existing account names, managed paths, firewall comments,
certificate lineage, and backup settings. Names containing `exomem` identify
existing host resources; changing collection ownership does not rename them.

The roles originate from Exomem and retain its AGPL-3.0-or-later license.
The full license is in `LICENSE`. On 2026-10-08, Substrate Systems packaged
the roles and qualified their SSH filter references for collection loading.
The repository's NetBird roles and administration playbooks remain outside
this collection.

## Build and distribution

The editable source lives in `substrate-infra/ansible/`. Consumers install a
generated collection tarball. Its provenance records the exact source commit,
collection version, builder versions, and artifact SHA-256 digest.
The tarball is a derived delivery copy; never edit its extracted files as source.

The collection uses Ansible Galaxy's native manifest allowlist. Builds require
the pinned Ansible Core and `distlib` versions from the source repository's
`requirements.txt`. Only the two roles, SSH filter, runtime metadata, README,
changelog, and license enter the package.

1. Update the source collection, version, and changelog, establishing a new reviewed release.
2. Export the clean source commit, fixing the exact build input.
3. Run `ansible-galaxy collection build` in the exported collection directory, producing the versioned tarball.
4. Record the source commit, builder versions, and SHA-256 digest, binding provenance to that tarball.
5. Validate the public artifact, confirming its contents match the allowed package and privacy requirements.
6. Install that tarball with `ansible-galaxy collection install`, making the reviewed package available for verification.
7. Verify role resolution, filters, and consumer workflows, recording proof against the installed artifact.
8. Deliver the tarball and provenance together, giving consumers a verifiable package pin.

Local source-repository verification installs its own built artifact. Public
consumers use the distributed tarball and provenance without private repository
access or an additional CI credential.
