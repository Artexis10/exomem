# Changelog

## 0.1.0 — 2026-10-08

Package the existing shared host and PostgreSQL roles as `substrate.infrastructure`.
Qualify SSH filters for collection loading and preserve managed host resources.
